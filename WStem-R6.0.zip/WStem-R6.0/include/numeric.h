#ifndef NUMERIC_H
#define NUMERIC_H

/**
 @file numeric
 @brief For functions involving numbers
*/

/**
 * @brief Determines if a string is a number or not
 * 
 * @param str The string to find numbers
 * 
 * @return 1 if a number, 0 if not
 */
int isNumeric(char* str);

/**
 * @brief Determines if a character is a digit
 * 
 * @param c The character to determine if an int
 * 
 * @return 1 if a int, 0 if not
 */
int isDigit(char c);


#endif
