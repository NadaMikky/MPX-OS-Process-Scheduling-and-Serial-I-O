#ifndef SYS_CALL_H
#define SYS_CALL_H
#include <stdint.h>

/**
 * @file sys_call.h
 * @brief The file containing sys_call which handles context switching.
 */


/**
 * @brief Manages system calls by context switching. 
 * Handles cases like switching processes to IDLE and replacing it 
 * with the next ready process in queue, terminating a currently 
 * running process if it has been completed, and system calls for 
 * reading and writing, but returning errors if the input is 
 * incorrect form. 
 * 
 * @param curr_context
 * @return The current context of the process after system call execution
 */
context *sys_call(context *curr_context);


#endif // SYS_CALL_H
