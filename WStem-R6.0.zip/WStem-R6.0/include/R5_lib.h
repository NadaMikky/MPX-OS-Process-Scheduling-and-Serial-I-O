#ifndef R5_LIB_H
#define R5_LIB_H

#include <stddef.h>

/**
 * @file R5_lib.h
 * @brief Provides memory management functions for heap allocation and deallocation.
 */

// Define the MCB structure
struct mcb {
    size_t size;               // Size of the memory block
    int is_allocated;          // 1 if allocated, 0 if free
    struct mcb *next;          // Pointer to the next MCB
    struct mcb *prev;         // Pointer to the previous MCB
    void *start_address;       // Start address of the memory block
};

// Functions to manage the memory lists
struct mcb *get_free_memory_list(void);
struct mcb *get_allocated_memory_list(void);
void set_free_memory_list(struct mcb *list);
void set_allocated_memory_list(struct mcb *list);

/**
 * @brief Initializes the heap with a single large free block
 *
 * @param heapSize: The total size of the heap (excluding the size of the initial MCB).
 */
void initialize_heap(size_t heapSize);

/**
 * @brief Allocates memory from the heap using the first-fit strategy
 *
 * @param allocateSize: The size, in bytes, of the requested allocation.
 *
 * @return: Pointer to the start address of the newly allocated block, or NULL on error.
 */
void *allocate_memory(size_t allocateSize);

/**
 * @brief Frees allocated memory and merges adjacent free blocks
 *
 * @param ptr: Pointer to the start address of an allocated block.
 *
 * @return: 0 on success, non-zero on error.
 */
int free_memory(void *ptr);

/**
 * @brief Clears the pointer of the allocated memory
 *
 * @param ptr: Pointer to the allocated memory
 *
 */
void* sys_alloc_zeroed_mem(size_t num, size_t size);

#endif // R5_LIB_H
