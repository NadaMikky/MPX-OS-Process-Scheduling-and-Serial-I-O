#ifndef USERGETSET_H
#define USERGETSET_H

/**
 * @file usergetset.h
 * @brief Get and set the date and time from the user input at the user level.
 */

/**
 * @brief Gets the time from user input.
 */
void get_time_cmd(void);

/**
 * @brief Sets the time from user input and calls a set within the kernel.
 */
void set_time_cmd(void);

/**
 * @brief Gets the date from the kernel.
 * 
 * @return The formatted date in DD/MM/YY
 */
char* get_date_cmd(void);

/**
 * @brief Sets the date from user input and calls a set within the kernel.
 */
void set_date_cmd(void);

#endif // USERGETSET_H
