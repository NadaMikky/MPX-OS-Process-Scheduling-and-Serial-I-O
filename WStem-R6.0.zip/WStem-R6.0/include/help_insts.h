#ifndef HELP_INSTS_H
#define HELP_INSTS_H

// R1 commands
void version_help(void);
void help_help(void);
void shutdown_help(void);
void get_time_help(void);
void set_time_help(void);
void get_date_help(void);
void set_date_help(void);

// R2: PCB commands
void delete_pcb_help(void);
void suspend_pcb_help(void);
void resume_pcb_help(void);
void set_pcb_priority_help(void);
void show_pcb_help(void);
void show_ready_help(void);
void show_blocked_help(void);
void show_all_help(void);

// R3: Load commands
void load_r3_help(void);
void load_r3_suspended_help(void);
void load_proc1_help(void);
void load_proc2_help(void);
void load_proc3_help(void);
void load_proc4_help(void);
void load_proc5_help(void);

// R4: Alarm command
void alarm_help(void);

// R5: Memory commands
void show_allocated_memory_help(void);
void show_free_memory_help(void);

// Notes
void notes_help(void);

#endif // HELP_INSTS_H
