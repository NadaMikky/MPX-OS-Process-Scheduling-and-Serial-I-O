#ifndef COLORS_STYLES_H
#define COLORS_STYLES_H

// ANSI escape codes for colors and styles - declarations only

extern const char bold[];       // Bold for emphasis
extern const char underline[];  // Underline for emphasis
extern const char reset[];      // Back to default color
extern const char yellow[];     // Yellow means warning/highlight for emphasis
extern const char red[];        // Red for error
extern const char green[];      // Green for success
extern const char pink[];       // Pink for WSTEM logo
extern const char blue[];       // Blue for info

#endif // COLORS_STYLES_H
