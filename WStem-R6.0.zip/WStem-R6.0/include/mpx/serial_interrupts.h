#ifndef SERIAL_INTERRUPTS_H
#define SERIAL_INTERRUPTS_H

#include <mpx/io.h>
#include <mpx/serial.h>
#include <sys_req.h>
#include <string.h>
#include <memory.h>
#include <string.h>
#include <mpx/interrupts.h>
#include <stdlib.h>
#include <sys_req.h>
#include <mpx/device.h>

#define RING_BUFFER_SIZE 100  // The size of the ring buffer for input data

#define MAX_DEVICES 4 // Supports up to 4 devices (COM1, COM2, etc.)

extern struct dcb *dcb_table[MAX_DEVICES]; // Global array of DCBs

// Device Control Block (DCB) status
typedef enum{
    IDLING,
    READING,
    WRITING,
} DCBStatus;

// Device Control Block (DCB) structure for the serial port driver
struct dcb{
    device device_id;        // Device ID (COM1, COM2, etc.)
    int open;                // Flag indicating whether the port is open (1 for open, 0 for closed)
    int eventFlag;           // Event flag for signaling completion (0: not complete, 1: complete)
    DCBStatus status;          // Current status: IDLE, WRITE, READ, or EXIT
    struct iocb **currentIOCB;    // Pointer to the head of the queue of IOCBs for this device

    // Input Buffer Information (for direct read operations)
    char *inputBuffer;       // Pointer to the requestor's input buffer
    size_t inputBufferSize;  // Total size (or requested number of characters) for the input buffer
    size_t inputCount;       // Counter for the number of characters already transferred

    // Output Buffer Information (for direct write operations)
    char *outputBuffer;       // Pointer to the requestor's output buffer
    size_t outputBufferSize;  // Total count of characters to be transferred
    size_t outputCount;       // Counter for the number of characters already transferred

    // Ring Buffer for serial port input data
    char ringBuffer[RING_BUFFER_SIZE]; // Fixed-size array for input ring buffering
    size_t ringInputIndex;    // Index where the next character should be inserted into the ring buffer
    size_t ringOutputIndex;   // Index from where the next character should be read out of the ring buffer
    size_t ringCount;         // Current number of characters stored in the ring buffer
};

struct dcb *get_dcb_by_device(device device_id); // Function to retrieve the DCB by device ID

/**
 * @brief Opens a serial port.
 * 
 * Initializes the serial port and prepares it for communication.
 * 
 * @param dev Pointer to the device ID (e.g., COM1, COM2, ...).
 * @param speed Baud rate for communication.
 * @return 0 on success, -1 on failure.
 */
int serial_open(device dev, int speed);

/**
 * @brief Closes a serial port.
 * 
 * Disables the serial port and releases associated resources.
 * 
 * @param dev Device ID (e.g., COM1, COM2, ...)
 * @return 0 on success, -201 if the port is not open.
 */
int serial_close(device dev);

/**
 * @brief Reads data from the serial port.
 * 
 * @param dev Device ID (e.g., COM1, COM2, ...)
 * @param buf: Pointer to the buffer where the read data will be stored
 * @param len: Length of the buffer
 * @return Number of bytes read on success or a negative error code on failure
 */
int serial_read(device dev, char *buf, size_t len);


/**
 * @brief Function to write data from the serial port.
 * 
 * @param dev Device ID (e.g., COM1, COM2, ...)
 * @param buf: Pointer to the buffer where the read data will be stored
 * @param len: Length of the buffer
 * @return Number of bytes written on success or a negative error code on failure
 */
int serial_write(device dev, char *buf, size_t len);

/**
 * @brief Handles serial port interrupts.
 * 
 * @param context Pointer to the interrupt context (can be NULL if unused)
 */
void serial_interrupt(void);

 /**
 * @brief Handles the input interrupt for the serial port.
 * @param dcb: Pointer to the DCB structure for the device
 */
void serial_input_interrupt(struct dcb *dcb);

 /**
 * @brief Handles the output interrupt for the serial port.
 * @param dcb: Pointer to the DCB structure for the device
 */
void serial_output_interrupt(struct dcb *dcb);

/**
 * @brief Handles the error interrupt for the serial port.
 * @param dcb: Pointer to the DCB structure for the device
 */
int device_id_to_int(device dev);

/**
 * @brief Checks if the device ID is valid.
 * @param dev: Device ID to check
 * @return 1 if valid, 0 otherwise
 */
int valid_device(device dev);

/**
 * @brief Converts an integer to a device ID.
 * @param i: Integer to convert
 * @return Corresponding device ID
 */
device device_int_to_dev(int i);

/**
 * @brief Polls the ring buffer for a specific character.
 * @param dcb: Pointer to the DCB structure for the device
 * @param c Character to poll for
 * @return 1 if the character is found, 0 otherwise
 */
int pollChar(struct dcb *dcb, char c);


/**
 * @brief Initializes the DCB structure and calls sys_free_mem to free the DCB itself.
 * @param dev: Device ID to initialize
 * @return Pointer to the initialized DCB structure
 */
void freeDCB(struct dcb* dcb);

#endif // SERIAL_INTERRUPTS_H
