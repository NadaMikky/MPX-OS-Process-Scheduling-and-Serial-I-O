#ifndef COMMANDHANDLER_H
#define COMMANDHANDLER_H

/**
 * @file commandHandler.h
 * @brief Command handler header file for MPX.
 */

/**
 * @brief Command handler function in commandHandler.c
 */
void comhand(void);

/**
 * @brief Displays the MPX version and latest compile date.
 */
void version_command(void);

/**
 * @brief Shuts the system down.
 *
 * @return int Returns 0 on cancelled shutdown, 1 if confirmed shutdown.
 */
int shutdown_command(void);

/**
 * @brief Gets user input for the PCB name
 *
 * @return char* user given PCB name
 */
char *get_PCB_name(void);

/**
 * @brief Gets user input for the PCB class
 *
 * @return int Returns 0 for system, 1 for user, other for error.
 */
int get_PCB_class(void);

/**
 * @brief Sets the PCB priority between 0 (less important) and 9 (most important)
 *
 * @return int Returns a priority between 0 and 9
 */
int get_PCB_priority(void);

/**
 * @brief Checks to ensure proper input for any numerical input with a range
 * @param prompt prompts the user to enter a value for the alarm
 * @param min_val minimum value of the input
 * @param max_val maximum value of the input
 * @param length the length that the input can be
 * 
 * @return returns the valid user input as an integer
*/
int get_numerical_input(const char *prompt, int min_val, int max_val, int length);

#endif // COMMANDHANDLER_H
