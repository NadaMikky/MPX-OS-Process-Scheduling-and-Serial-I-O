#ifndef IO_SCHEDULER_H
#define IO_SCHEDULER_H

/** Helper Method
 * @brief Checks and updates the event flags for all devices.
 * Responsible for monitoring the event flags
 * of devices and updating their status based on the current
 * state of I/O operations.
 */
void check_event_flags(void);

// Files to be included in IO Scheduler... parameters, return values,
// and other parts of these functions may be changed to fit your
// implementation.

struct iocb {               
    struct pcb *pcb;         // Associated PCB
    struct dcb *dcb;         // Associated DCB
    op_code operation_type;  // Operation type (READ, WRITE)
    char* buffer;            // Pointer to the buffer
    size_t buffer_size;         // Size of the buffer
    struct iocb *next;       // Pointer to the next IOCB in the queue
};

/**
 * @brief Adds an IOCB to the end of the IOCB queue for a device
 * 
 * @param iocb I/O Control Block
 * @param head Pointer to the head IOCB
 * Uses First Come First Serve Methodology implying that the queue is in order of arrival
 * Each device has its own IOCB queue, and if a device is busy, the request gets enqueued,
 * and the process is blocked
 */
void enqueue_iocb(struct iocb *iocb, struct iocb **head);

/**
 * @brief Removes an IOCB from the front of the IOCB queue for a device
 * 
 * @param iocb I/O Control Block
 * @param head Pointer to the head IOCB
 * Pulls the next ready-to-run IOCB from the front. When an I/O operation finishes 
 * (e.g., in your interrupt handler), you’d call dequeue_iocb() and start the next 
 * transfer with that IOCB.
 */
struct iocb* dequeue_iocb(struct iocb **head);

//struct iocb* process_next_iocb(struct iocb *iocb);

void io_scheduler(op_code operation, device dev, char* buffer, size_t buffer_size, struct pcb* pcb); // passed structs for process and io instead of void, -subject to change-

/**
 * @brief Retrieves the head of the IOCB queue for a specific device.
 * 
 * @param dev Device ID (e.g., COM1, COM2, etc.)
 * @return Pointer to the head IOCB of the device's queue
 */
struct iocb **getHeadQ(device dev);

/**
 * @brief Frees the memory allocated for an IOCB.
 * 
 * @param iocb Pointer to the IOCB to be freed
 */
void iocb_free(struct iocb *iocb);

void allocateIOCBHeads(void); // Allocates memory for the IOCB heads

void freeIOCBHeads(void); // Frees memory for the IOCB heads

#endif // IO_SCHEDULER_H
