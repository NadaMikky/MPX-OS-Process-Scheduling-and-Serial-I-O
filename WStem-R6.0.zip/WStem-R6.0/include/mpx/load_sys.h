#ifndef LOAD_SYS_H
#define LOAD_SYS_H

/**
 * @brief Creates a comhand process
 * 
 * Creates a system process that runs the command handler. The
 * process is added to the ready queue and is set to the highest priority
 */
void load_comhand(void);

/**
 * @brief Creates a system idle process
 * 
 * Creates a system process that runs the sys_idle_process The
 * process is added to the ready queue and is set to the lowest priority
 */
void load_sys_idle(void);

#endif // LOAD_SYS_H
