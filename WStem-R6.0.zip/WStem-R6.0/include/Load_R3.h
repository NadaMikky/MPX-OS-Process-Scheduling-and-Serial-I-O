#ifndef LOAD_R3_H
#define LOAD_R3_H

/**
 * @file Load_R3.h
 * @brief Header file for loading and managing R3 processes.
 * This file provides function declarations for initializing and managing
 * processes for R3.  
 */

/**
 * Loads and initializes process 1.
 * Creates a PCB for proc1, sets its state to READY, and assigns 
 * its execution context.
 */
void load_proc1(void);

/**
* Loads and initializes process 2.
 * Creates a PCB for proc2, sets its state to READY, and assigns 
 * its execution context.
 */
void load_proc2(void);

/**
 * Loads and initializes process 3.
 * Creates a PCB for proc3, sets its state to READY, and assigns 
 * its execution context.
 */
void load_proc3(void);

/**
 * Loads and initializes process 4.
 * Creates a PCB for proc4, sets its state to READY, and assigns 
 * its execution context.
 */
void load_proc4(void);

/**
 * Loads and initializes process 5.
 * Creates a PCB for proc5, sets its state to READY, and assigns 
 * its execution context.
 */
void load_proc5(void);

/**
 * Loads all R3 processes and initializes their execution contexts.
 * Calls helper functions to load individual processes and prepares them
 * for execution by placing them in the ready queue.
 */
void load_r3_user(void);

/**
 * Loads a specific process with a given number and priority
 * for the bonus opportunity.
 * 
 * @param num The process number (1-5).
 * @param priority The priority of the process (0-9).
 */
void load_process(int num, int priority);

#endif // LOAD_R3_H
