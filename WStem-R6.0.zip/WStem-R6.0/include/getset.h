#ifndef GETSET_H
#define GETSET_H

/**
 * @file getset.h
 * @brief Get and set the date and time at the kernel level.
 */

/**
 * @brief Concatenates two strings into a pre-allocated buffer.
 * 
 * @param str1 The first string.
 * @param str2 The second string.
 * @param buffer The pre-allocated buffer to store the concatenated string.
 * @return A pointer to the concatenated string (same as buffer).
 */
char* concat(const char *str1, const char *str2, char *buffer);

/**
 * @brief Gets the hour in decimal form.
 * 
 * @return The current hour.
 */
int get_hour(void);

/**
 * @brief Gets the minutes in decimal form.
 * 
 * @return The current minutes.
 */
int get_min(void);

/**
 * @brief Gets the seconds in decimal form.
 * 
 * @return The current seconds.
 */
int get_sec(void);

/**
 * @brief Gets the time at the kernel level.
 * 
 * @return The formatted time.
 */
char* get_time(void);

/**
 * @brief Sets the time within the system.
 * 
 * @param hour The hour to set.
 * @param min The minutes to set.
 * @param sec The seconds to set.
 */
void set_time(int hour, int min, int sec);

/**
 * @brief Calculates how many days are in a given month.
 * 
 * @param month The month to check.
 * @param year The year to check.
 * @param century The century to check
 * @return The number of days in the given month.
 */
int days_in_month(int month, int year, int century);

/**
 * @brief Gets the century in decimal format
 * 
 * @return The current century.
 */
int get_century(void);

/**
 * @brief Gets the year in decimal form.
 * 
 * @return The current year.
 */
int get_year(void);

/**
 * @brief Gets the month in decimal form.
 * 
 * @return The current month.
 */
int get_month(void);

/**
 * @brief Gets the day in decimal form.
 * 
 * @return The current day.
 */
int get_day(void);

/**
 * @brief Gets the date from the user input at the kernel level.
 * 
 * @return The formatted date.
 */
char* get_date(void);

/**
 * @brief Sets the date within the system at the kernel level.
 * 
 * @param year The year to set.
 * @param month The month to set.
 * @param day The day to set.
 * @param century The century to set
 */
void set_date(int century, int year, int month, int day);

#endif // GETSET_H




