#ifndef PCB_H
#define PCB_H

#define STACK_SIZE 3072

#define READY 0
#define BLOCKED 1

#define NOT_SUSPENDED 0
#define SUSPENDED 1

#define SYSTEM_PROCESS 0
#define USER_PROCESS 1

#define RUNNING 2

extern struct pcb *get_ready_queue;             // The head of the ready queue
extern struct pcb *get_blocked_queue;           // The head of the blocked queue
extern struct pcb *get_suspended_ready_queue;   // The head of the suspended ready queue
extern struct pcb *get_suspended_blocked_queue; // The head of the suspended blocked queue

/**
 * @file pcb.h
 * @brief Defines the structures and functions for managing Process Control Blocks (PCBs)
 */

 /**
 * @struct context
 * @brief Context of currently running processes
 *
 * ...
 */
typedef struct context
{
    unsigned int ds;       // Data segment register
    unsigned int es;       // Extra segment register
    unsigned int fs;       // FS segment register (used for thread-local storage or other purposes)
    unsigned int gs;       // GS segment register (used for thread-local storage or other purposes)
    unsigned int ss;       // Stack segment register
    unsigned int eax;      // Accumulator register (used for return values and arithmetic operations)
    unsigned int ebx;      // Base register (used for addressing memory)
    unsigned int ecx;      // Counter register (used for loops and string operations)
    unsigned int edx;      // Data register (used for I/O operations and arithmetic)
    unsigned int esi;      // Source index register (used for string operations)
    unsigned int edi;      // Destination index register (used for string operations)
    unsigned int ebp;      // Base pointer register (used for stack frame management)
    unsigned int eip;      // Instruction pointer register (points to the next instruction to execute)
    unsigned int cs;       // Code segment register
    unsigned int eflags;   // Flags register (contains status flags, control flags, and system flags)
}context;

/**
 * @struct pcb
 * @brief Represents a Process Control Block (PCB)
 *
 *  A PCB stores information about a process, including its state,
 *  priority, and memory allocation.
 */
struct pcb
{
    int pid;                // Process ID
    char name[32];          // Name of the process
    char stack[STACK_SIZE]; // Process stack
    char *stackPtr;         // Stack pointer
    int state;              // Process state
    int priority;           // Process priority
    int suspended;          // Suspension state
    int class;              // Process class
    struct pcb *next;       // Pointer to the next PCB in the queue
    struct pcb *prev;       // Pointer to the previous PCB in the queue
};

/**
 * @brief Allocates memory for a new PCB.
 *
 *  Uses sys alloc mem() to allocate memory for a new PCB,
 *  including the stack, and perform reasonable initialization.
 *
 * @return A pointer to a newly allocated PCB on success
 */
struct pcb *pcb_allocate(void);

/**
 * @brief Frees the memory associated with a PCB
 *
 * Uses sys free mem() to free all memory associated with
 * a PCB, including the stack
 *
 * @param new_pcb A pointer to the PCB to free.
 * @return A code indicating success or error
 */
int pcb_free(struct pcb *new_pcb);

/**
 * @brief Creates and initializes a new PCB
 *
 * Allocates (via allocate pcb()) a new PCB, initializes it with
 * data provided, and sets the state to Ready, Not-suspended.
 *
 * @param name The process name.
 * @param class The process class
 * @param priority The process priority
 *
 * @return A pointer to the initialized PCB on success
 */
struct pcb *pcb_setup(const char *name, int class, int priority);

/**
 * @brief Searches for a process by name
 *
 * Searches all process queues for a process with a provided name
 *
 * @param name The name of the process to find.
 * @return A pointer to the found PCB on success
 */
struct pcb *pcb_find(const char *name);

/**
 * @brief Inserts a PCB into the appropriate queue
 *
 * Inserts a PCB into the appropriate queue based on state and (if Ready) priority.
 *
 * @param new_pcb A pointer to the PCB to enqueue.
 */
void pcb_insert(struct pcb *new_pcb);

/**
 * @brief Removes a PCB from its current queue
 *
 * Removes a PCB from its current queue, but does not free
 * any associated memory or data structures.
 *
 * @param new_pcb A pointer to the PCB to unqueue.
 * @return A success or error code
 */
int pcb_remove(struct pcb *new_pcb);


/**
 * @brief Clears all the PCBs from the queues
 *
 * Clears all PCBs from the ready and blocked queues
 *
 */
void clearAllPCBs(void);

#endif
