#ifndef ALARM_H
#define ALARM_H
typedef struct
{
    int hh, mm, ss;
    char message[100];
} Alarm;


// Function to compare alarm time with the current time.
// Returns 1 if the alarm time is in the past or current time, 0 if in the future.
int CheckTime(Alarm *alarm);

// Function to create a new alarm process.
// Takes in a time and message, and sets up an alarm to trigger at the specified time.
void setAlarm(char *time, char *msg);

// Function to start the alarm and display the alarm message if it's the correct time.
// Takes in the alarmCount to identify which alarm to start.
void startAlarm(char alarmCount);

// Function to set up an alarm with a specific time (hours, minutes, seconds) and a message.
// It creates a PCB for the alarm process and schedules it for execution.
void setupAlarm(int hr, int min, int sec, char *msg);

#endif /* ALARM_H */
