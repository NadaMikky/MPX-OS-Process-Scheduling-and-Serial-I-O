#ifndef COMMANDS_H
#define COMMANDS_H

#include <stddef.h>
#include <stdint.h> // Include for uintptr_t
#include <pcb.h>    // Include the header where struct pcb is defined

/**
 * @file commands.h
 * @brief Declares functions for handling user commands and managing PCBs, processes, and memory.
 */

/*
 * Converts an integer to a string representation.
 * @param num: The integer to convert.
 * @param str: The buffer to store the resulting string.
 * Returns: void
 */
void itoa_pcb(int num, char *str);

/*
 * Prints the details of a PCB.
 * @param PCB: Pointer to the PCB structure to print.
 * Returns: void
 */
void print_pcb(struct pcb *PCB);

/**
 * @brief Prints the current version of MPX and the compilation date.
 */
void version_command(void);

/**
 * @brief Provides usage instructions for all commands.
 *
 * Describes what each command does, how to use it, and any constraints or examples.
 * Makes a constant for each command to avoid overflow.
 *
 * @param command The command to display help for.
 */
void help_command(void);

/**
 * @brief Shuts down the system.
 *
 * Exits the command handler loop and execution will return to kmain() and the system will halt.
 * MUST ask for confirmation.
 *
 * @return int Returns 0 on cancelled shutdown, 1 if confirmed shutdown.
 */
int shutdown(void);

/*
 * Creates a PCB with a given name, class and priority
 * @param name:name of the PCB. Must be a valid, non-empty string not exceeding the maximum allowed length.
 * @param class: process class (e.g., SYSTEM_PROCESS or USER_PROCESS).
 * @param priority: The priority of the PCB, typically in the range 0 (highest) to 9 (lowest).
 * Returns: void
 */
void create_pcb(const char *name, int class, int priority);

/*
 * Deletes a PCB with a given name
 * @param name: Name of the PCB to block
 * Returns: void
 */
void delete_pcb(const char *name);

// removed block and unblock for R6

/*
 * Suspends a PCB with a given name.
 * @param name: Name of the PCB to suspend.
 * Returns: void
 */
void suspend_pcb(const char *name);

/*
 * Resumes a PCB with a given name.
 * @param name: Name of the PCB to resume.
 * Returns: void
 */
void resume_pcb(const char *name);

/*
 * Sets/changes the priority of a PCB.
 * @param name: Name of the PCB.
 * @param priority: New priority (0 to 9)
 * Returns: void
 */
void set_pcb_priority(const char *name, int priority);

/*
 * Shows the information of a PCB.
 * @param name: Name of the PCB to display/show
 * Returns: void
 */
void show_pcb(const char *name);

/*
 * Displays all PCBs in the Ready queue
 * Parameters: None
 * Returns: void
 */
void show_ready(void);

/*
 * Shows information of PCBs in the blocked queue
 * Parameters: None
 * Returns: void
 */
void show_blocked(void);

/*
 * Shows information of all PCBs
 * Parameters: None
 * Returns: void
 */
void show_all(void);

/*
 * Prints the info on a PCB
 * Parameters: None
 * Returns: void
 */
void print_pcb(struct pcb *PCB);

/*
 * Loads proc1 into memory in a suspended state.
 * Parameters: None
 * Returns: void
 */
void load_proc1_suspended(void);

/*
 * Loads proc2 into memory in a suspended state.
 * Parameters: None
 * Returns: void
 */
void load_proc2_suspended(void);

/*
 * Loads proc3 into memory in a suspended state.
 * Parameters: None
 * Returns: void
 */
void load_proc3_suspended(void);

/*
 * Loads proc4 into memory in a suspended state.
 * Parameters: None
 * Returns: void
 */
void load_proc4_suspended(void);

/*
 * Loads proc5 into memory in a suspended state.
 * Parameters: None
 * Returns: void
 */
void load_proc5_suspended(void);

/*
 * Cause Command Handler to yield the CPU
 * Parameters: None
 * Returns: void
 */
void yield(void);

/*
 * Loads R3 user processes by calling the load_r3_user function from Load_R3.c
 * Parameters: None
 * Returns: void
 */
void load_r3(void);

/*
 * Loads the R3 processes into memory in a suspended state.
 * Parameters: None
 * Returns: void
 */
void load_r3_suspended(void);

/*
 * calls the setAlarm() function 
 * Parameters: None
 * Returns: void
 */
void alarm(void);

/*
 * Allocates heap memory by calling allocate memory()
 * Parameters: size of allocation request (in decimal)
 * Returns: void
 */
void allocate_mem(size_t allocateSize);

/*
 * Frees heap memory by calling free memory()
 * Parameters: address of the memory block (not MCB) to free (in hexadecimal)
 * Returns: void
 */
void free_mem(void *address);

/*
 * Displays all allocated memory blocks.
 * Parameters: None
 * Returns: void
 */
void show_allocated_memory(void);

/*
 * Displays all free memory blocks in the heap.
 * Parameters: None
 * Returns: void
 */
void show_free_memory(void);

#endif // COMMANDS_H
