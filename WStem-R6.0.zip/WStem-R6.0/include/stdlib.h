#ifndef MPX_STDLIB_H
#define MPX_STDLIB_H

/**
 @file stdlib.h
 @brief A subset of standard C library functions.
*/

/**
 @brief Converts an ASCII string to an integer
 @param s A NUL-terminated string
 @return The value of the string converted to an integer
*/
int atoi(const char *s);

/**
 @brief Converts a base 10 integer to a string.
 @param buff The buffer to store the resulting string (must be pre-allocated).
 @param n The base 10 integer to convert.
 */
void itoa(char *buff, int n);

/**
 @brief Calculates the power of a number
 @param num The base number
 @param expo The exponent
 @return The result of num raised to the power of expo
*/
int mathPower(int num, int expo);

/**
 @brief Converts a decimal number to hexadecimal and print it
 @param dec The decimal number to convert
 @return 0 on success
*/
int decimalToHex(unsigned int dec);

/**
 @brief Converts a hexadecimal string to a decimal number
 @param hex The hexadecimal string
 @param hexSize The length of the hexadecimal string
 @return The decimal value of the hexadecimal string, or -1 if invalid
*/
int hexToDecimal(char *hex, unsigned int hexSize);


#endif
