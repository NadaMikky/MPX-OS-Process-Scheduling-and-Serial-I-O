#include <processes.h>
#include <mpx/commandHandler.h>
#include <mpx/io.h>
#include <sys_req.h>
#include <stdlib.h>
#include <ctype.h>
#include <getset.h>
#include <pcb.h>
#include <commands.h>
#include <stddef.h>
#include <Load_R3.h>
#include <colors_styles.h>
#include <numeric.h>
#include <string.h>

/*
 * Helper functions for each process:
 * Each load_procX() function creates a PCB, sets it as READY, and assigns execution to procX.
 * These functions ensure that processes are properly initialized and added to the ready queue.
 */

// Function to load process 1
void load_proc1(void)
{
   // Check if a PCB for "proc1" already exists
   struct pcb *find_pcb = pcb_find("proc1");

   if (find_pcb != NULL)
   {
      // If the process already exists, print an error message and return
      sys_req(WRITE, COM1, red, strlen(red));
      sys_req(WRITE, COM1, "Process Not Created: proc1 already exists.\n", 44);
      sys_req(WRITE, COM1, reset, strlen(reset));
      return;
   }

   // Create and set up a new PCB for "proc1"
   struct pcb *new_pcb = pcb_setup("proc1", 1, 3); // Priority 1, Class 3
   new_pcb->suspended = NOT_SUSPENDED;             // Mark the process as not suspended
   new_pcb->state = READY;                         // Mark the process as ready

   // Set up the context for the process
   struct context *new_context = (struct context *)(new_pcb->stackPtr);

   // Initialize segment registers
   new_context->cs = 0x08;
   new_context->ds = 0x10;
   new_context->es = 0x10;
   new_context->fs = 0x10;
   new_context->gs = 0x10;
   new_context->ss = 0x10;

   // Set the stack and base pointers
   new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

   // Set the instruction pointer to the function "proc1"
   new_context->eip = (unsigned int)(proc1);

   // Set the EFLAGS register to 0x0202 (default flags)
   new_context->eflags = 0x0202;

   // Initialize general-purpose registers to 0
   new_context->eax = 0;
   new_context->ebx = 0;
   new_context->ecx = 0;
   new_context->edx = 0;
   new_context->esi = 0;
   new_context->edi = 0;

   // Insert the PCB into the ready queue
   pcb_insert(new_pcb);

   // Print a success message
   sys_req(WRITE, COM1, green, strlen(green));
   sys_req(WRITE, COM1, "Process Created Successfully: proc1.\n", 38);
   sys_req(WRITE, COM1, reset, strlen(reset));
}

// Function to load process 2
void load_proc2(void)
{
   // Check if a PCB for "proc2" already exists
   struct pcb *find_pcb = pcb_find("proc2");

   if (find_pcb != NULL)
   {
      // If the process already exists, print an error message and return
      sys_req(WRITE, COM1, red, strlen(red));
      sys_req(WRITE, COM1, "Process Not Created: proc2 already exists.\n", 44);
      sys_req(WRITE, COM1, reset, strlen(reset));
      return;
   }

   // Create and set up a new PCB for "proc2"
   struct pcb *new_pcb = pcb_setup("proc2", 1, 3); // Priority 1, Class 3
   new_pcb->suspended = NOT_SUSPENDED;             // Mark the process as not suspended
   new_pcb->state = READY;                         // Mark the process as ready

   // Set up the context for the process
   struct context *new_context = (struct context *)(new_pcb->stackPtr);

   // Initialize segment registers
   new_context->cs = 0x08;
   new_context->ds = 0x10;
   new_context->es = 0x10;
   new_context->fs = 0x10;
   new_context->gs = 0x10;
   new_context->ss = 0x10;

   // Set the stack and base pointers
   new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

   // Set the instruction pointer to the function "proc2"
   new_context->eip = (unsigned int)(proc2);

   // Set the EFLAGS register to 0x0202 (default flags)
   new_context->eflags = 0x0202;

   // Initialize general-purpose registers to 0
   new_context->eax = 0;
   new_context->ebx = 0;
   new_context->ecx = 0;
   new_context->edx = 0;
   new_context->esi = 0;
   new_context->edi = 0;

   // Insert the PCB into the ready queue
   pcb_insert(new_pcb);

   // Print a success message
   sys_req(WRITE, COM1, green, strlen(green));
   sys_req(WRITE, COM1, "Process Created Successfully: proc2.\n", 38);
   sys_req(WRITE, COM1, reset, strlen(reset));
}

// Function to load process 3
void load_proc3(void)
{
   // Check if a PCB for "proc3" already exists
   struct pcb *find_pcb = pcb_find("proc3");

   if (find_pcb != NULL)
   {
      // If the process already exists, print an error message and return
      sys_req(WRITE, COM1, red, strlen(red));
      sys_req(WRITE, COM1, "Process Not Created: proc3 already exists.\n", 44);
      sys_req(WRITE, COM1, reset, strlen(reset));
      return;
   }

   // Create and set up a new PCB for "proc2"
   struct pcb *new_pcb = pcb_setup("proc3", 1, 3); // Priority 1, Class 3
   new_pcb->suspended = NOT_SUSPENDED;             // Mark the process as not suspended
   new_pcb->state = READY;                         // Mark the process as ready

   // Set up the context for the process
   struct context *new_context = (struct context *)(new_pcb->stackPtr);

   // Initialize segment registers
   new_context->cs = 0x08;
   new_context->ds = 0x10;
   new_context->es = 0x10;
   new_context->fs = 0x10;
   new_context->gs = 0x10;
   new_context->ss = 0x10;

   // Set the stack and base pointers
   new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

   // Set the instruction pointer to the function "proc3"
   new_context->eip = (unsigned int)(proc3);

   // Set the EFLAGS register to 0x0202 (default flags)
   new_context->eflags = 0x0202;

   // Initialize general-purpose registers to 0
   new_context->eax = 0;
   new_context->ebx = 0;
   new_context->ecx = 0;
   new_context->edx = 0;
   new_context->esi = 0;
   new_context->edi = 0;

   // Insert the PCB into the ready queue
   pcb_insert(new_pcb);

   // Print a success message
   sys_req(WRITE, COM1, green, strlen(green));
   sys_req(WRITE, COM1, "Process Created Successfully: proc3.\n", 38);
   sys_req(WRITE, COM1, reset, strlen(reset));
}


// Function to load process 4
void load_proc4(void)
{
   // Check if a PCB for "proc4" already exists
   struct pcb *find_pcb = pcb_find("proc4");

   if (find_pcb != NULL)
   {
      // If the process already exists, print an error message and return
      sys_req(WRITE, COM1, red, strlen(red));
      sys_req(WRITE, COM1, "Process Not Created: proc4 already exists.\n", 44);
      sys_req(WRITE, COM1, reset, strlen(reset));
      return;
   }

   // Create and set up a new PCB for "proc2"
   struct pcb *new_pcb = pcb_setup("proc4", 1, 3); // Priority 1, Class 3
   new_pcb->suspended = NOT_SUSPENDED;             // Mark the process as not suspended
   new_pcb->state = READY;                         // Mark the process as ready

   // Set up the context for the process
   struct context *new_context = (struct context *)(new_pcb->stackPtr);

   // Initialize segment registers
   new_context->cs = 0x08;
   new_context->ds = 0x10;
   new_context->es = 0x10;
   new_context->fs = 0x10;
   new_context->gs = 0x10;
   new_context->ss = 0x10;

   // Set the stack and base pointers
   new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

   // Set the instruction pointer to the function "proc4"
   new_context->eip = (unsigned int)(proc4);

   // Set the EFLAGS register to 0x0202 (default flags)
   new_context->eflags = 0x0202;

   // Initialize general-purpose registers to 0
   new_context->eax = 0;
   new_context->ebx = 0;
   new_context->ecx = 0;
   new_context->edx = 0;
   new_context->esi = 0;
   new_context->edi = 0;

   // Insert the PCB into the ready queue
   pcb_insert(new_pcb);

   // Print a success message
   sys_req(WRITE, COM1, green, strlen(green));
   sys_req(WRITE, COM1, "Process Created Successfully: proc4.\n", 38);
   sys_req(WRITE, COM1, reset, strlen(reset));
}

// Function to load process 5
void load_proc5(void)
{
   // Check if a PCB for "proc5" already exists
   struct pcb *find_pcb = pcb_find("proc5");

   if (find_pcb != NULL)
   {
      // If the process already exists, print an error message and return
      sys_req(WRITE, COM1, red, strlen(red));
      sys_req(WRITE, COM1, "Process Not Created: proc5 already exists.\n", 44);
      sys_req(WRITE, COM1, reset, strlen(reset));
      return;
   }

   // Create and set up a new PCB for "proc5"
   struct pcb *new_pcb = pcb_setup("proc5", 1, 3); // Priority 1, Class 3
   new_pcb->suspended = NOT_SUSPENDED;             // Mark the process as not suspended
   new_pcb->state = READY;                         // Mark the process as ready

   // Set up the context for the process
   struct context *new_context = (struct context *)(new_pcb->stackPtr);

   // Initialize segment registers
   new_context->cs = 0x08;
   new_context->ds = 0x10;
   new_context->es = 0x10;
   new_context->fs = 0x10;
   new_context->gs = 0x10;
   new_context->ss = 0x10;

   // Set the stack and base pointers
   new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

   // Set the instruction pointer to the function "proc5"
   new_context->eip = (unsigned int)(proc5);

   // Set the EFLAGS register to 0x0202 (default flags)
   new_context->eflags = 0x0202;

   // Initialize general-purpose registers to 0
   new_context->eax = 0;
   new_context->ebx = 0;
   new_context->ecx = 0;
   new_context->edx = 0;
   new_context->esi = 0;
   new_context->edi = 0;

   // Insert the PCB into the ready queue
   pcb_insert(new_pcb);

   // Print a success message
   sys_req(WRITE, COM1, green, strlen(green));
   sys_req(WRITE, COM1, "Process Created Successfully: proc5.\n", 38);
   sys_req(WRITE, COM1, reset, strlen(reset));
}

/*
 * Function to load all processes for R3.
 * Calls each helper function to initialize and load the respective processes.
 */
void load_r3_user(void)
{
   load_proc1();
   load_proc2();
   load_proc3();
   load_proc4();
   load_proc5();
}

void load_process(int num, int priority){

   // Check if the process number is valid
   if(num < 1 || num > 5){
      sys_req(WRITE, COM1, red, strlen(red));
      sys_req(WRITE, COM1, "Invalid process number. Must be between 1 and 5.\n", 50);
      sys_req(WRITE, COM1, reset, strlen(reset));
      return;
   }

   // Check if the priority is valid
   if(priority < 0 || priority > 9){
      sys_req(WRITE, COM1, red, strlen(red));
      sys_req(WRITE, COM1, "Invalid priority number. Must be between 0 and 9.\n", 51);
      sys_req(WRITE, COM1, reset, strlen(reset));
      return;
   }

   char name[6]; // Buffer to hold the process name
   char n[12]; /// Allocate a buffer large enough to hold the string representation
   itoa(n, num); // Convert the process number to a string

   // Creates the "procX" name
   name[0] = 'p';
   name[1] = 'r';
   name[2] = 'o';
   name[3] = 'c';
   name[4] = *n;
   name[5] = '\0'; // Null-terminate the string

   // Check if a PCB for the process already exists
   struct pcb *find_pcb = pcb_find(name);

   if (find_pcb != NULL)
   {
      // If the process already exists, print an error message and return
      sys_req(WRITE, COM1, red, strlen(red));
      sys_req(WRITE, COM1, "Process Not Created: process already exists.\n", 44);
      sys_req(WRITE, COM1, reset, strlen(reset));
      return;
   }

   // Create and set up a new PCB for the process
   struct pcb *new_pcb = pcb_setup(name, 1, priority); // System class with custom priority
   new_pcb->suspended = SUSPENDED;             // Mark the process as not suspended
   new_pcb->state = READY;                         // Mark the process as ready

   // Set up the context for the process
   struct context *new_context = (struct context *)(new_pcb->stackPtr);

   // Initialize segment registers
   new_context->cs = 0x08;
   new_context->ds = 0x10;
   new_context->es = 0x10;
   new_context->fs = 0x10;
   new_context->gs = 0x10;
   new_context->ss = 0x10;

   // Set the stack and base pointers
   new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

   // Set the instruction pointer to the function
   if(num==1){
      new_context->eip = (unsigned int)(proc1);
   }else if(num==2){
      new_context->eip = (unsigned int)(proc2);
   }else if(num==3){ 
      new_context->eip = (unsigned int)(proc3);
   }else if(num==4){
      new_context->eip = (unsigned int)(proc4);
   }else if(num==5){
      new_context->eip = (unsigned int)(proc5);
   }
   else{
      sys_req(WRITE, COM1, red, strlen(red));
      sys_req(WRITE, COM1, "Invalid process number. Must be between 1 and 5.\n", 50);
      sys_req(WRITE, COM1, reset, strlen(reset));
      return;
   }

   // Set the EFLAGS register to 0x0202 (default flags)
   new_context->eflags = 0x0202;

   // Initialize general-purpose registers to 0
   new_context->eax = 0;
   new_context->ebx = 0;
   new_context->ecx = 0;
   new_context->edx = 0;
   new_context->esi = 0;
   new_context->edi = 0;

   // Insert the PCB into the ready queue
   pcb_insert(new_pcb);

   // Print a success message
   sys_req(WRITE, COM1, green, strlen(green));
   sys_req(WRITE, COM1, "The Following Process Created Successfully:\n", 45);
   sys_req(WRITE, COM1, reset, strlen(reset));

   print_pcb(new_pcb); // Print the PCB information
}
