#include <string.h>
#include <sys_req.h>
#include <stdlib.h>
#include <getset.h>
#include <numeric.h>
#include <colors_styles.h>

void get_time_cmd(void)
{

    // Initialize sec, min, hr in BINARY ..
    char *time = get_time();

    sys_req(WRITE, COM1, blue, strlen(blue));
    sys_req(WRITE, COM1, time, strlen(time));
    sys_req(WRITE, COM1, "\n", 1);
    sys_req(WRITE, COM1, reset, strlen(reset));

    // FOR FUTURE IMPLEMENTATION
    // print statement for "your time is: " without a new line
    //  sys_free();
    // get_time(buffer);
}

void set_time_cmd(void)
{

    // Initialize time variables
    int hour = 0;
    int min = 0;
    int sec = 0;

    // Prompt user for hour input
    static char *user_hr = "Enter an hour (00-23): ";
    static char *user_min = "Enter minutes (00-59): ";
    static char *user_sec = "Enter seconds (00-59): ";

    // Check validity of hour input
    do
    {

        char hr_buff[3] = {0}; // Creates an hour buffer

        // Prints prompt for hour and reads user provided hour from the terminal
        sys_req(WRITE, COM1, user_hr, strlen(user_hr));
        sys_req(READ, COM1, hr_buff, 3);
        
        if (isNumeric(hr_buff) == 1)
        {
            hour = atoi(hr_buff); // Hour from character to int
        }
        else
        {
            hour = -1; // not valid
        }

        if (hour < 0 || hour > 23) // If answer is out of bound
        {
            sys_req(WRITE, COM1, red, strlen(red));
            sys_req(WRITE, COM1, "Your answer is not in the bounds provided, try again.\n", 55);
            sys_req(WRITE, COM1, reset, strlen(reset));
        }

    } while (hour < 0 || hour > 23); // While hour is inclusively between 0 and 23

    // Check validity of minutes input
    do
    {
        char min_buff[3] = {0}; // Creates an min buffer

        // Prints prompt for minute and reads user provided minute from the terminal
        sys_req(WRITE, COM1, user_min, strlen(user_min));
        sys_req(READ, COM1, min_buff, 3);

        if (isNumeric(min_buff) == 1)
        {
            min = atoi(min_buff); // Hour from character to int
        }
        else
        {
            min = -1; // not valid
        }

        if (min < 0 || min > 59) // If answer is out of bounds
        {
            sys_req(WRITE, COM1, red, strlen(red));
            sys_req(WRITE, COM1, "Your answer is not in the bounds provided, try again.\n", 55);
            sys_req(WRITE, COM1, reset, strlen(reset));
        }

    } while (min < 0 || min > 59); // While min is between inclusively 0 and 59

    // Check validity of seconds input
    do
    {
        char sec_buff[3] = {0}; // Creates a second buffer

        // Prints prompt for minute and reads user provided second from the terminal
        sys_req(WRITE, COM1, user_sec, strlen(user_sec));

        sys_req(READ, COM1, sec_buff, 3);

        if (isNumeric(sec_buff) == 1)
        {
            sec = atoi(sec_buff); // Hour from character to int
        }
        else
        {
            sec = -1; // not valid
        }

        if (sec < 0 || sec > 59) // If answer is out of bounds
        {
            sys_req(WRITE, COM1, red, strlen(red));
            sys_req(WRITE, COM1, "Your answer is not in the bounds provided, try again.\n", 55);
            sys_req(WRITE, COM1, reset, strlen(reset));
        }

    } while (sec < 0 || sec > 59); // While sec is inclusively between 0 and 59.

    set_time(hour, min, sec); // Sets time
}

void get_date_cmd(void)
{

    char *date = get_date(); // Gets the date in registers

    // Outputs the date and a new line
    sys_req(WRITE, COM1, blue, strlen(blue));
    sys_req(WRITE, COM1, date, strlen(date));
    sys_req(WRITE, COM1, "\n", 1);
    sys_req(WRITE, COM1, reset, strlen(reset));

}

void set_date_cmd(void)
{

    // Initialize day, month, year
    int day = 0;
    int month = 0;
    int year = 0;
    int century = 0;

    // Prompt user for year input
    static char *user_century = "Enter an century (17-21): ";
    static char *user_year = "Enter an year (0-99): ";
    static char *user_month = "Enter a month (1-12): ";
    static char *user_day = "Enter a day (1-31; end bound depending on month): ";

    do
    {
        char century_buff[3] = {0}; // Creates a year buffer

        // Prints prompt for year and reads user provided year from the terminal
        sys_req(WRITE, COM1, user_century, strlen(user_century));
        sys_req(READ, COM1, century_buff, 3);

        if (isNumeric(century_buff) == 1)
        {
            century = atoi(century_buff); // Hour from character to int
        }
        else
        {
            century = -1; // not valid
        }

        if (century < 17 || century > 21)
        {
            sys_req(WRITE, COM1, red, strlen(red));
            sys_req(WRITE, COM1, "Your answer is not in the bounds provided, try again.\n", 55);
            sys_req(WRITE, COM1, reset, strlen(reset));
        }

    } while (century < 17 || century > 21); //  While year is inclusively between 0 and 99.

    // Check validity of year input
    do
    {
        char year_buff[3] = {0}; // Creates a year buffer

        // Prints prompt for year and reads user provided year from the terminal
        sys_req(WRITE, COM1, user_year, strlen(user_year));
        sys_req(READ, COM1, year_buff, 3);

        if (isNumeric(year_buff) == 1)
        {
            year = atoi(year_buff); // Hour from character to int
        }
        else
        {
            year = -1; // not valid
        }

        if (year < 0 || year > 99)
        {
            sys_req(WRITE, COM1, red, strlen(red));
            sys_req(WRITE, COM1, "Your answer is not in the bounds provided, try again.\n", 55);
            sys_req(WRITE, COM1, reset, strlen(reset));
        }

    } while (year < 0 || year > 99); //  While year is inclusively between 0 and 99.

    // Check validity of month input
    do
    {
        char month_buff[3] = {0}; // Creates a month buffer

        // Prints prompt for month and reads user provided month from the terminal
        sys_req(WRITE, COM1, user_month, strlen(user_month));
        sys_req(READ, COM1, month_buff, 3);

        if (isNumeric(month_buff) == 1)
        {
            month = atoi(month_buff); // Hour from character to int
        }
        else
        {
            month = -1; // not valid
        }

        
        if (month < 1 || month > 12)
        {
            sys_req(WRITE, COM1, red, strlen(red));
            sys_req(WRITE, COM1, "Your answer is not in the bounds provided, try again.\n", 55);
            sys_req(WRITE, COM1, reset, strlen(reset));
        }

    } while (month < 1 || month > 12); // While month is inclusively between 1 and 12.

    // Check validity of day input
    do
    {
        char day_buff[3] = {0};

        // Prints prompt for day and reads user provided day from the terminal
        sys_req(WRITE, COM1, user_day, strlen(user_day));
        sys_req(READ, COM1, day_buff, 2);

        if (isNumeric(day_buff) == 1)
        {
            day = atoi(day_buff); // Hour from character to int
        }
        else
        {
            day = -1; // not valid
        }
                
        if (day < 1 || day > days_in_month(month, year, century))
        {
            sys_req(WRITE, COM1, red, strlen(red));
            sys_req(WRITE, COM1, "Your answer is not in the bounds provided, try again.\n", 55);
            sys_req(WRITE, COM1, reset, strlen(reset));
        }

    } while (day < 1 || day > days_in_month(month, year, century)); // While day is inclusively between 1 and the max number of days in a certain month.
    
    set_date(century, year, month, day); // Set the date
}
