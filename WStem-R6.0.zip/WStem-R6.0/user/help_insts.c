#include <string.h>
#include <mpx/commandHandler.h>
#include <mpx/io.h>
#include <sys_req.h>
#include <stdlib.h>
#include <ctype.h>
#include <getset.h>
#include <pcb.h>
#include <commands.h>
#include <processes.h>
#include <Load_R3.h>
#include <alarm.h>
#include <R5_lib.h>
#include <colors_styles.h>
#include <numeric.h>
#include <mpx/io_scheduler.h>
#include <help_insts.h>

void version_help(void)
{
    sys_req(WRITE, COM1, "1. version:\n", 13);
    sys_req(WRITE, COM1, "   Description: Displays the current version of MPX.\n", 54);
    sys_req(WRITE, COM1, "   How to use it? Type 'version' the press Enter.\n\n", 52);
}

void help_help(void)
{
    sys_req(WRITE, COM1, "2. help:\n", 10);
    sys_req(WRITE, COM1, "   Description: Displays a list of all available commands and instructions\n", 76);
    sys_req(WRITE, COM1, "   for their usage.\n", 21);
    sys_req(WRITE, COM1, "   How to use it? Type 'help' then press Enter.\n\n", 50);
}

void shutdown_help(void)
{
    sys_req(WRITE, COM1, "3. shutdown:\n", 14);
    sys_req(WRITE, COM1, "   Description: Shuts down the operating system.\n", 50);
    sys_req(WRITE, COM1, "   How to use it? Type 'shutdown' then press Enter. You will be prompted to confirm.\n", 86);
    sys_req(WRITE, COM1, "   Type 'Y' or 'y' and enter to confirm or 'N' or 'n' to stop.\n", 64);
    sys_req(WRITE, COM1, "   Any other answer will cancel the shutdown process.\n\n", 56);
}

void get_time_help(void)
{
    sys_req(WRITE, COM1, "4. get time:\n", 14);
    sys_req(WRITE, COM1, "   Description: Displays the current system time.\n", 51);
    sys_req(WRITE, COM1, "   How to use it? Type 'get time' then press Enter.\n\n", 54);
}

void set_time_help(void)
{
    sys_req(WRITE, COM1, "5. set time:\n", 14);
    sys_req(WRITE, COM1, "   Description: Sets the system time.\n", 39);
    sys_req(WRITE, COM1, "   How to use it? Type 'set time' then it will prompt you to enter the time in the order\n", 90);
    sys_req(WRITE, COM1, "   of hours, minutes, then seconds. Each prompt will explain the range acceptable.\n", 84);
    sys_req(WRITE, COM1, "   Press enter when complete with each input.\n", 47);
    sys_req(WRITE, COM1, "   If it is an invalid input, it will further reprompt you for a valid time\n", 77);
    sys_req(WRITE, COM1, "   until one is presented.\n", 28);
    sys_req(WRITE, COM1, "   Example: Enter set time, then fill the time prompts with 12, then 31, and 10\n", 81);
    sys_req(WRITE, COM1, "   to set the time to 12:31:10. (12th minute, 31st minute, and 10th second)\n\n", 78);
}

void get_date_help(void)
{
    sys_req(WRITE, COM1, "6. get date:\n", 14);
    sys_req(WRITE, COM1, "   Description: Displays the current system date in MM/DD/CCYY format.\n", 72);
    sys_req(WRITE, COM1, "   How to use it? Type 'get date' then press Enter.\n\n", 54);
}

void set_date_help(void)
{
    sys_req(WRITE, COM1, "7. set date:\n", 14);
    sys_req(WRITE, COM1, "   Description: Sets the system date.\n", 39);
    sys_req(WRITE, COM1, "   How to use it? Type 'set date' where the terminal will then prompt you for\n", 79);
    sys_req(WRITE, COM1, "   CC (the century), YY (the final two digits of the year), MM (the month (1-12)),\n", 84);
    sys_req(WRITE, COM1, "   and DD (the day (1-31 depending on the month)). The year can only be set in the 21st century.\n", 98);
    sys_req(WRITE, COM1, "   Each prompt will explain the range acceptable.\n", 51);
    sys_req(WRITE, COM1, "   Press enter when complete with each input.\n", 47);
    sys_req(WRITE, COM1, "   If it is an invalid input, it will further reprompt you for a valid date \n", 78);
    sys_req(WRITE, COM1, "   until one is presented.\n", 28);
    sys_req(WRITE, COM1, "   Example: Enter set date, then fill the date prompts with 20, then 10, then 12, and 30\n", 90);
    sys_req(WRITE, COM1, "   to set the date to 12/30/2010. (December 30th 2010)\n\n", 57);
}

void delete_pcb_help(void)
{
    sys_req(WRITE, COM1, "1. delete pcb: \n", 16);
    sys_req(WRITE, COM1, "   Description: Deletes an existing PCB from the system.\n", 58);
    sys_req(WRITE, COM1, "   How to use it? Type 'delete pcb' then press enter, you'll be\n", 65);
    sys_req(WRITE, COM1, "   prompted to enter a PCB Name.\n\n", 35);
}

void suspend_pcb_help(void)
{
    sys_req(WRITE, COM1, "2. suspend pcb: \n", 18);
    sys_req(WRITE, COM1, "   Description: Suspends a PCB, preventing it from being scheduled.\n", 69);
    sys_req(WRITE, COM1, "   How to use it? Type 'suspend pcb' then press enter, you'll be prompted to enter the name\n", 93);
    sys_req(WRITE, COM1, "   of PCB you want to suspend\n\n", 32);
}

void resume_pcb_help(void)
{
    sys_req(WRITE, COM1, "3. resume pcb: \n", 17);
    sys_req(WRITE, COM1, "   Description: Resumes a previously suspended PCB, allowing it to be scheduled again.\n", 88);
    sys_req(WRITE, COM1, "   How to use it? Type 'resume pcb' then press enter, you'll be prompted to enter the name\n", 92);
    sys_req(WRITE, COM1, "   of PCB you want to resume.\n\n", 32);
}

void set_pcb_priority_help(void)
{
    sys_req(WRITE, COM1, "4. set pcb priority: \n", 23);
    sys_req(WRITE, COM1, "   Description: Changes the priority of an existing PCB.\n", 58);
    sys_req(WRITE, COM1, "   How to use it? Type 'set pcb priority' then press enter, you'll be prompted to enter:\n", 90);
    sys_req(WRITE, COM1, "   a. Name of PCB to set priority of\n", 38);
    sys_req(WRITE, COM1, "   b. Desired priority to PCB (0-9)\n\n", 38);
}

void show_pcb_help(void)
{
    sys_req(WRITE, COM1, "5. show pcb: \n", 15);
    sys_req(WRITE, COM1, "   Description: Displays details about a specific PCB (e.g: name, state, ...etc).\n", 83);
    sys_req(WRITE, COM1, "   How to use it? Type 'show pcb' then press enter, you'll be prompted to enter the\n", 85);
    sys_req(WRITE, COM1, "   name of PCB you want to display.\n\n", 38);
}

void show_ready_help(void)
{
    sys_req(WRITE, COM1, "6. show ready: \n", 17);
    sys_req(WRITE, COM1, "   Description: Displays all PCBs currently in the ready queue.\n", 65);
    sys_req(WRITE, COM1, "   How to use it? Type 'show ready' and press Enter.\n\n", 55);
}

void show_blocked_help(void)
{
    sys_req(WRITE, COM1, "7. show blocked: \n", 19);
    sys_req(WRITE, COM1, "   Description: Displays all PCBs currently in the blocked queue.\n", 67);
    sys_req(WRITE, COM1, "   How to use it? Type 'show blocked' and press Enter.\n\n", 57);
}

void show_all_help(void)
{
    sys_req(WRITE, COM1, "8. show all: \n", 15);
    sys_req(WRITE, COM1, "    Description: Displays all PCBs in the system, including ready and blocked states.\n", 87);
    sys_req(WRITE, COM1, "    How to use it? Type 'show all' and press Enter.\n\n", 54);
}

void load_r3_help(void)
{
    sys_req(WRITE, COM1, "1. load r3: \n", 14);
    sys_req(WRITE, COM1, "   Description: Loads the R3 test processes in a non-suspended state.\n ", 72);
    sys_req(WRITE, COM1, "   How to use it? Type 'load r3' and press Enter. \n\n", 53);
}

void load_r3_suspended_help(void)
{
    sys_req(WRITE, COM1, "2. load r3 suspended:\n", 23);
    sys_req(WRITE, COM1, "   Description: Loads the R3 test processes in a suspended state.\n", 67);
    sys_req(WRITE, COM1, "   How to use it? Type 'load r3 suspended' and press Enter. \n\n", 63);
}

void load_proc1_help(void)
{
    sys_req(WRITE, COM1, "3. load proc1:\n", 16);
    sys_req(WRITE, COM1, "   Description: Loads process 1, a R3 test process, in a suspended state.\n", 75);
    sys_req(WRITE, COM1, "   How to use it? Type 'load proc1', the desired priority number and press Enter. \n\n", 85);
}

void load_proc2_help(void)
{
    sys_req(WRITE, COM1, "4. load proc2:\n", 16);
    sys_req(WRITE, COM1, "   Description: Loads process 2, a R3 test process, in a suspended state.\n", 75);
    sys_req(WRITE, COM1, "   How to use it? Type 'load proc2', the desired priority number and press Enter. \n\n", 85);
}

void load_proc3_help(void)
{
    sys_req(WRITE, COM1, "5. load proc3:\n", 16);
    sys_req(WRITE, COM1, "   Description: Loads process 3, a R3 test process, in a suspended state.\n", 75);
    sys_req(WRITE, COM1, "   How to use it? Type 'load proc3', the desired priority number and press Enter. \n\n", 85);
}

void load_proc4_help(void)
{
    sys_req(WRITE, COM1, "6. load proc4:\n", 16);
    sys_req(WRITE, COM1, "   Description: Loads process 4, a R3 test process, in a suspended state.\n", 75);
    sys_req(WRITE, COM1, "   How to use it? Type 'load proc4', the desired priority number and press Enter. \n\n", 85);
}

void load_proc5_help(void)
{
    sys_req(WRITE, COM1, "7. load proc5:\n", 16);
    sys_req(WRITE, COM1, "   Description: Loads process 5, a R3 test process, in a suspended state.\n", 75);
    sys_req(WRITE, COM1, "   How to use it? Type 'load proc5', the desired priority number and press Enter. \n\n", 85);
}

// void alarm_help(void)
// {
//     sys_req(WRITE, COM1, "1. set alarm:\n", 15);
//     sys_req(WRITE, COM1, "   Description: It will set an alarm with a specific time and message\n", 71);
//     sys_req(WRITE, COM1, "   chosen by the user.\n", 24);
//     sys_req(WRITE, COM1, "   How to use it? Type 'set alarm' and press Enter, you'll be prompted to enter: \n", 83);
//     sys_req(WRITE, COM1, "   a. Time for the alarm in the format:  \n", 43);
//     sys_req(WRITE, COM1, "     i. Enter an hour (00-23)\n", 31);
//     sys_req(WRITE, COM1, "     ii. Enter minutes (00-59)\n", 32);
//     sys_req(WRITE, COM1, "     iii. Enter seconds (00-59)\n", 33);
//     sys_req(WRITE, COM1, "     Press Enter after each input.\n", 36);
//     sys_req(WRITE, COM1, "    b. Message of the alarm. (e.g meeting, test, class, ...etc)\n\n", 66);
// }

void show_allocated_memory_help(void)
{
    sys_req(WRITE, COM1, "1. show allocated memory:\n", 27);
    sys_req(WRITE, COM1, "    Description: Displays all allocated memory blocks.\n", 56);
    sys_req(WRITE, COM1, "    How to use it? Type 'show allocated memory' then press Enter.\n", 67);
    sys_req(WRITE, COM1, "    It will list each allocated block with: start address (in hex) and block size (in decimal)\n\n", 97);
}

void show_free_memory_help(void)
{
    sys_req(WRITE, COM1, "2. show free memory:\n", 22);
    sys_req(WRITE, COM1, "    Description: Displays all free memory blocks available in the heap.\n", 73);
    sys_req(WRITE, COM1, "    How to use it? Type 'show free memory' then press Enter.\n", 62);
    sys_req(WRITE, COM1, "    It will list each allocated block with: start address (in hex) and block size (in decimal)\n\n", 97);
}

void notes_help(void)
{
    sys_req(WRITE, COM1, "NOTES & TIPS:\n", 15);
    sys_req(WRITE, COM1, "   - Commands are case-sensitive.\n", 35);
    sys_req(WRITE, COM1, "   - Ensure proper format when using commands that require arguments.\n", 71);
    sys_req(WRITE, COM1, "   - Make sure there is no trailing or leading whitespace.\n", 60);
    sys_req(WRITE, COM1, "       For example the help command will only accept \"help\" and not \" help \".\n\n", 80);
}
