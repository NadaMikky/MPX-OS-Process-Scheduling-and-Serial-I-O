#include <string.h>
#include <mpx/commandHandler.h>
#include <mpx/io.h>
#include <mpx/interrupts.h>
#include <sys_req.h>
#include <stdlib.h>
#include <ctype.h>
#include <usergetset.h>
#include <commands.h>
#include <memory.h>
#include <numeric.h>
#include <mpx/load_sys.h>
#include <pcb.h>
#include <alarm.h>
#include <Load_R3.h>
#include <colors_styles.h>
#include <R5_lib.h>
int running = 1;

// This is the logo for WSTEM, DO NOT MESS WITH THIS
const char logoPt1[] = "__        __  _____   _____  _____  __  __  \n";
const char logoPt2[] = "\\ \\      / / / ____| |_   _|| ____||  \\/  | \n";
const char logoPt3[] = " \\ \\ /\\ / / | (_____   | |  | |___ | |\\/| | \n";
const char logoPt4[] = "  \\ V  V /   \\_____ \\  | |  | ____|| |  | | \n";
const char logoPt5[] = "   \\ /\\ /    _____) |  | |  | |___ | |  | | \n";
const char logoPt6[] = "    v  v     |______/  |_|  | ____||_|  |_| \n";

void comhand(void)
{
    // START UP SEQUENCE AND
    sys_req(WRITE, COM1, bold, strlen(bold));
    sys_req(WRITE, COM1, " \n               Welcome to the \n", 34);
    sys_req(WRITE, COM1, reset, strlen(reset));
    sys_req(WRITE, COM1, pink, strlen(pink));
    sys_req(WRITE, COM1, logoPt1, strlen(logoPt1));
    sys_req(WRITE, COM1, logoPt2, strlen(logoPt2));
    sys_req(WRITE, COM1, logoPt3, strlen(logoPt3));
    sys_req(WRITE, COM1, logoPt4, strlen(logoPt4));
    sys_req(WRITE, COM1, logoPt5, strlen(logoPt5));
    sys_req(WRITE, COM1, logoPt6, strlen(logoPt6));
    sys_req(WRITE, COM1, reset, strlen(reset));
    sys_req(WRITE, COM1, bold, strlen(bold));
    sys_req(WRITE, COM1, "              Operating System \n\n", 34);
    sys_req(WRITE, COM1, reset, strlen(reset));

    // Writes the message for the user to know what to do if they need help on what to do next
    sys_req(WRITE, COM1, underline, strlen(underline)); // Underline for emphasis
    sys_req(WRITE, COM1, "Don't know where to start? Type \"help\"\n", 40);
    sys_req(WRITE, COM1, reset, strlen(reset)); // Back to default
    sys_req(WRITE, COM1, "\n", 1);

    // While the system is running
    while (running)
    {
        // Create a buffer of size 100 to store the user input
        char buf[100] = {0};

        // Prompts the user for a command
        sys_req(WRITE, COM1, "Enter command to Start: ", 24);

        // While the user has not entered anything, keep reading
        sys_req(READ, COM1, buf, sizeof(buf));

        // Process the version command when "version" is typed
        if (strcmp(buf, "version") == 0)
        {
            version_command();
        }

        // Process the help command when "help" is typed
        else if (strcmp(buf, "help") == 0)
        {
            help_command();
        }
        // Process the shutdown command when "shutdown" is typed
        else if (strcmp(buf, "shutdown") == 0)
        {
            running = shutdown_command(); // Set running to 0 to stop the loop
        }
        // Process the get time command when "gettime" is typed
        else if (strcmp(buf, "get time") == 0)
        {
            get_time_cmd();
        }
        // Process the set time command when "settime" is typed
        else if (strcmp(buf, "set time") == 0)
        {
            set_time_cmd();
        }
        // Process the get date command when "getdate" is typed
        else if (strcmp(buf, "get date") == 0)
        {
            get_date_cmd();
        }
        // Process the set date command when "setdate" is typed
        else if (strcmp(buf, "set date") == 0)
        {
            set_date_cmd();
        }
        // Clears the entire terminal when "clear" is typed
        else if (strcmp(buf, "clear") == 0)
        {
            sys_req(WRITE, COM1, "\x1B[3J", 4); // erases saved lines (not on screen)
            sys_req(WRITE, COM1, "\x1B[H", 3);  // resets cursor to home (0,0)
            sys_req(WRITE, COM1, "\x1B[2J", 4); // erases entire visible screen
        }
        // Start of R2 commands
        else if (strcmp(buf, "delete pcb") == 0)
        {
            char *pcb_name = get_PCB_name();

            delete_pcb(pcb_name);
            sys_free_mem(pcb_name); // Frees allocated memory from the name
        }
        // Suspends a PCB with given name
        else if (strcmp(buf, "suspend pcb") == 0)
        {
            char *pcb_name = get_PCB_name();

            suspend_pcb(pcb_name);
            sys_free_mem(pcb_name); // Frees allocated memory from the name
        }
        // Resumes a PCB with given name
        else if (strcmp(buf, "resume pcb") == 0)
        {
            char *pcb_name = get_PCB_name();

            resume_pcb(pcb_name);
            sys_free_mem(pcb_name); // Frees allocated memory from the name
        }
        // Sets the priority of a PCB with given name
        else if (strcmp(buf, "set pcb priority") == 0)
        {
            char* pcb_name = get_PCB_name();

            int pcb_priority = get_PCB_priority();

            set_pcb_priority(pcb_name, pcb_priority);
            sys_free_mem(pcb_name); // Frees allocated memory from the name
        }
        // Shows the details of a PCB with given name
        else if (strcmp(buf, "show pcb") == 0)
        {
            char *pcb_name = get_PCB_name();
            sys_req(WRITE, COM1, underline, strlen(underline));
            sys_req(WRITE, COM1, "\nShowing the PCB:\n\n", 20);
            sys_req(WRITE, COM1, reset, strlen(reset));
            show_pcb(pcb_name);
            sys_free_mem(pcb_name); // Frees allocated memory from the name
        }
        // Shows all PCBs in the ready queue
        else if (strcmp(buf, "show ready") == 0)
        {
            show_ready();
        }
        // Shows all PCBs in the blocked queue
        else if (strcmp(buf, "show blocked") == 0)
        {
            show_blocked();
        }
        // Shows all PCBs in the system
        else if (strcmp(buf, "show all") == 0)
        {
            show_all();
        }
        // Start of R3 commands
        // Loads R3 test processes in a non-suspended state
        else if (strcmp(buf, "load r3") == 0)
        {
            load_r3();
        }
        // Loads R3 test processes in a suspended state
        else if (strcmp(buf, "load r3 suspended") == 0)
        {
            load_r3_suspended();
        }
        // BONUS OPPORTUNITY: Load individual processes in ready and suspended state
        else if (strcmp(buf, "load proc1") == 0)
        {
            // Enter priority
            int priority = get_PCB_priority();
            load_process(1, priority);
        }
        else if (strcmp(buf, "load proc2") == 0)
        {
            // Enter priority
            int priority = get_PCB_priority();
            load_process(2, priority);
        }
        else if (strcmp(buf, "load proc3") == 0)
        {
            // Enter priority
            int priority = get_PCB_priority();
            load_process(3, priority);
        }
        else if (strcmp(buf, "load proc4") == 0)
        {
            // Enter priority
            int priority = get_PCB_priority();
            load_process(4, priority);
        }
        else if (strcmp(buf, "load proc5") == 0)
        {
            // Enter priority
            int priority = get_PCB_priority();
            load_process(5, priority);
        }
        // // Sets up alarm
        // else if (strcmp(buf, "set alarm") == 0)
        // {
        //     int hour = get_numerical_input("Enter hour (0-23): ", 0, 23, 2);
        //     int min = get_numerical_input("Enter minutes (0-59): ", 0, 59, 2);
        //     int sec = get_numerical_input("Enter seconds (0-59): ", 0, 59, 2);

        //     char* msg = (char *)sys_alloc_zeroed_mem(100, sizeof(char)); // Allocate memory for the message
        //     sys_req(WRITE, COM1, "Enter your alarm message (max 99 chars): ", 42);
        //     sys_req(READ, COM1, msg, 99);
            
        //     // Pass validated values to setupAlarm
        //     setupAlarm(hour, min, sec, msg);
        //     sys_req(WRITE, COM1, "Alarm has been set! \n", 21);
        //     free_mem(msg); // Free the allocated memory for the message
        // }
        // Shows allocated memory
        else if (strcmp(buf, "show allocated memory") == 0)
        {
            show_allocated_memory();
        }
        // Shows free memory
        else if (strcmp(buf, "show free memory") == 0)
        {
            show_free_memory();
        }
        // Informs the user when the command is not recognized (none of the above)
        else
        {
            sys_req(WRITE, COM1, yellow, strlen(yellow));
            sys_req(WRITE, COM1, "Command not recognized\n", 24);
            sys_req(WRITE, COM1, reset, strlen(reset));
        }

        // Yield for other processes
        sys_req(IDLE);
    }

    sys_req(EXIT);
}

char *get_PCB_name(void)
{
    char *pcb_name = (char *)sys_alloc_zeroed_mem(41, sizeof(char)); // Creates a pointer for the name with allocated memory
    int repeat = 0;                                             // Used to repeat the prompt if the name is invalid

    sys_req(WRITE, COM1, "Enter PCB Name: ", 17); // Prompts the user for the PCB name

    // A do while loop to get a valid name from the user
    do
    {
        // If the loop has been repeated, get another name from the user
        if (repeat == 1)
        {
            sys_req(WRITE, COM1, "\x1B[38;5;1m", 10); // Red for error
            sys_req(WRITE, COM1, "Invalid name, try again\n", 25);
            sys_req(WRITE, COM1, "\x1B[0m", 5); // Back to default color
            sys_req(WRITE, COM1, "Enter PCB Name: ", 17);
        }

        sys_req(READ, COM1, pcb_name, 40);

        if (!pcb_name || strlen(pcb_name) == 0 || strlen(pcb_name) > 40) // Check if the name is valid (will be further checked in create_pcb)
        {
            repeat = 1; // Invalid name, repeat
        }
        else
        {
            repeat = 0; // Valid name so far, continue
        }

    } while (repeat == 1);

    return pcb_name; // Returns the pointer w/ the name
}

int get_PCB_class(void)
{
    char *pcb_class = (char *)sys_alloc_zeroed_mem(2, (sizeof(char))); // Creates a pointer for the class with allocated memory
    int repeat = 0;                                       // Used to repeat the prompt if the class is invalid

    sys_req(WRITE, COM1, "Enter PCB Class (1 for user, 0 for system): ", 45); // Prompts the user for the PCB class

    // A do while loop to get a valid class from the user
    do
    {
        // If the loop has been repeated, get another class from the user
        if (repeat == 1)
        {
            sys_req(WRITE, COM1, "\x1B[38;5;1m", 10); // Red for error
            sys_req(WRITE, COM1, "Invalid class, try again\n", 26);
            sys_req(WRITE, COM1, "\x1B[0m", 5); // Back to default color
            sys_req(WRITE, COM1, "Enter PCB Class (1 for user, 0 for system): ", 45);
        }

        sys_req(READ, COM1, pcb_class, 2); // Read the user input if any

        strip_spaces(pcb_class); // Remove trailing and leading spaces from the class

        if (isDigit(*pcb_class) == 0 || (atoi(pcb_class) != 0 && atoi(pcb_class) != 1)) // Check if the class is valid (will be further checked in create_pcb)
        {
            repeat = 1; // Invalid class, repeat
        }
        else
        {
            repeat = 0; // Valid class so far, continue
        }

    } while (repeat == 1);

    int class = atoi(pcb_class); // Convert the string to an integer
    sys_free_mem(pcb_class); // Free the allocated memory for the class
    return class; // Returns the PCB class
}

int get_PCB_priority(void)
{
    char *pcb_priority = (char *)sys_alloc_zeroed_mem(2, (sizeof(char))); // Creates a pointer for the priority with allocated memory
    int repeat = 0;                                          // Used to repeat the prompt if the priority is invalid

    sys_req(WRITE, COM1, "Enter PCB Priority (Between 0-9): ", 35); // Prompts the user for the PCB priority

    // A do while loop to get a valid priority from the user
    do
    {
        // If the loop has been repeated, get another priority from the user
        if (repeat == 1)
        {
            sys_req(WRITE, COM1, "\x1B[38;5;1m", 10); // Red for error
            sys_req(WRITE, COM1, "Invalid priority, try again\n", 29);
            sys_req(WRITE, COM1, "\x1B[0m", 5); // Back to default color
            sys_req(WRITE, COM1, "Enter PCB Priority (Between 0-9): ", 35);
        }

        sys_req(READ, COM1, pcb_priority, 2); // Read the user input if any

        strip_spaces(pcb_priority); // Remove trailing and leading spaces from the priority

        if (isDigit(*pcb_priority) == 0 || atoi(pcb_priority) < 0 || atoi(pcb_priority) > 9) // Check if the priority is valid (will be further checked in create_pcb)
        {
            repeat = 1; // Invalid priority, repeat
        }
        else
        {
            repeat = 0; // Valid priority so far, continue
        }

    } while (repeat == 1);

    int priority = atoi(pcb_priority); // Convert the string to an integer
    sys_free_mem(pcb_priority); // Free the allocated memory for the priority
    return priority; // Returns the PCB priority
}

int get_numerical_input(const char *prompt, int min_val, int max_val, int length)
{
    char *input = (char *)sys_alloc_zeroed_mem(length + 1, sizeof(char)); // Allocate memory for a string with the given length + 1 for null terminator
    int repeat = 0;                         // Used to repeat the prompt if the input is invalid

    sys_req(WRITE, COM1, prompt, strlen(prompt)); // Display the initial prompt

    do
    {
        if (repeat == 1)
        {
            sys_req(WRITE, COM1, red, strlen(red));
            sys_req(WRITE, COM1, "Invalid input, try again\n", 25);
            sys_req(WRITE, COM1, reset, strlen(reset));
            sys_req(WRITE, COM1, prompt, strlen(prompt));
        }

        sys_req(READ, COM1, input, length);

        // Validate that input is numeric and within range
        if (!isNumeric(input))
        {
            repeat = 1; // Not numeric, repeat
        }
        else
        {
            int value = atoi(input);
            if (value < min_val || value > max_val)
            {
                repeat = 1; // Out of range, repeat
            }
            else
            {
                repeat = 0;          // Valid input
                sys_free_mem(input); // Free allocated memory
                return value;
            }
        }
    } while (repeat == 1);

    sys_free_mem(input); // Free allocated memory
    return -1; // Should never reach here
}
