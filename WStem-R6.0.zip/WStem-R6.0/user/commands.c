#include <string.h>
#include <mpx/commandHandler.h>
#include <mpx/io.h>
#include <sys_req.h>
#include <stdlib.h>
#include <ctype.h>
#include <getset.h>
#include <pcb.h>
#include <commands.h>
#include <processes.h>
#include <Load_R3.h>
#include <alarm.h>
#include <R5_lib.h>
#include <colors_styles.h>
#include <numeric.h>
#include <mpx/io_scheduler.h>
#include <help_insts.h>

void print_pcb(struct pcb *PCB)
{
    // Check if pcb = null --> ERROR
    if (PCB == NULL)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: PCB is NULL.\n", 21);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Prints the process name
    sys_req(WRITE, COM1, blue, strlen(blue)); // Blue for result
    sys_req(WRITE, COM1, "PCB Process Name: ", 19);
    sys_req(WRITE, COM1, PCB->name, strlen(PCB->name));
    sys_req(WRITE, COM1, "\n", 2);

    // Prints the PCB class
    sys_req(WRITE, COM1, "PCB Process Class: ", 20);
    if (PCB->class == SYSTEM_PROCESS)
        sys_req(WRITE, COM1, "SYSTEM (0)\n", 12);
    else if (PCB->class == USER_PROCESS)
        sys_req(WRITE, COM1, "USER (1)\n", 10);
    else
        sys_req(WRITE, COM1, "UNKNOWN\n", 9);

    // Print states (ready, blocked, suspended ready, and suspended blocked )
    sys_req(WRITE, COM1, "PCB Process State and Suspension Status: ", 42);

    if (PCB->state == READY && PCB->suspended == NOT_SUSPENDED)
    {
        sys_req(WRITE, COM1, "READY & UNSUSPENDED\n", 21);
    }
    else if (PCB->state == BLOCKED && PCB->suspended == NOT_SUSPENDED)
    {
        sys_req(WRITE, COM1, "BLOCKED & UNSUSPENDED\n", 23);
    }
    else if (PCB->state == READY && PCB->suspended == SUSPENDED)
    {
        sys_req(WRITE, COM1, "READY & SUSPENDED\n", 19);
    }
    else if (PCB->state == BLOCKED && PCB->suspended == SUSPENDED)
    {
        sys_req(WRITE, COM1, "BLOCKED & SUSPENDED\n", 21);
    }
    else
    {
        sys_req(WRITE, COM1, "UNRECOGNIZED!\n", 15); // Error if unknown state, should not be able to get to this.
    }

    char priority_str[3]; // Buffer for priority string
    itoa(priority_str, PCB->priority);
    sys_req(WRITE, COM1, "PCB Process Priority: ", 23);
    sys_req(WRITE, COM1, priority_str, strlen(priority_str)); // Print priority
    sys_req(WRITE, COM1, "\n\n", 3);
    sys_req(WRITE, COM1, reset, strlen(reset));
}

void version_command(void)
{
    sys_req(WRITE, COM1, blue, strlen(blue));
    const char *version = "MPX Version: R6\n";
    sys_req(WRITE, COM1, version, strlen(version));
    sys_req(WRITE, COM1, reset, strlen(reset));
}

void help_command(void)
{
    // R1 commands
    sys_req(WRITE, COM1, blue, strlen(blue));
    sys_req(WRITE, COM1, "\nAvailable Commands:\n\n", 23);

    version_help();
    help_help();
    shutdown_help();
    get_time_help();
    set_time_help();
    get_date_help();
    set_date_help();

    // R2 commands written by:
    sys_req(WRITE, COM1, "PCB Commands:\n\n", 16);
    delete_pcb_help();
    suspend_pcb_help();
    resume_pcb_help();
    set_pcb_priority_help();
    show_pcb_help();
    show_ready_help();
    show_blocked_help();
    show_all_help();

    // R3 commands written by:
    sys_req(WRITE, COM1, "Loading R3 Processes:\n\n", 24);
    load_r3_help();
    load_r3_suspended_help();
    load_proc1_help();
    load_proc2_help();
    load_proc3_help();
    load_proc4_help();
    load_proc5_help();

    // R4 command written by:
    // sys_req(WRITE, COM1, "Alarm Command:\n\n", 17);
    // alarm_help();

    // R5 commands written by:
    sys_req(WRITE, COM1, "Memory Commands:\n\n", 19);
    show_allocated_memory_help();
    show_free_memory_help();

    notes_help();
    sys_req(WRITE, COM1, reset, strlen(reset));
}

int shutdown_command(void)
{

    // Outputs a confirmation to shutdown or not
    sys_req(WRITE, COM1, "Are you sure you want to shutdown? type (y) or (n): ", 53);

    // Gets the
    char confirmation[2];
    sys_req(READ, COM1, confirmation, sizeof(confirmation));

    if (confirmation[0] == 'y' || confirmation[0] == 'Y')
    {
        sys_req(WRITE, COM1, green, strlen(green));
        sys_req(WRITE, COM1, "Shutting down...\n", 17);
        sys_req(WRITE, COM1, reset, strlen(reset));
        clearAllPCBs();
        freeIOCBHeads();
        return 0;
    }
    else if (confirmation[0] == 'n' || confirmation[0] == 'N')
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Shutdown cancelled.\n", 20);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return 1;
    }
    else
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Neither option chosen. Shutdown cancelled.\n", 43);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return 1;
    }
}

// R2 commands:
void delete_pcb(const char *name)
{
    // Name must be valid
    if (!name || strlen(name) == 0 || strlen(name) > 8)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Invalid process name.\n", 30);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    struct pcb *PCB = pcb_find(name); // Find/locate the PCB

    // Check if the PCB was found
    if (!PCB)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: PCB not found.\n", 23);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Ensure the PCB is not a system process
    if (PCB->class == SYSTEM_PROCESS)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Cannot delete system process.\n", 38);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    int getval = pcb_remove(PCB); // Remove the PCB from the queue

    // Check if the PCB was removed successfully
    if (getval != 0)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: PCB could not be removed from queue.\n", 45);
        sys_req(WRITE, COM1, reset, strlen(reset));
        ;
    }

    pcb_free(PCB); // Free associated memory using the kernel pcb_free
    sys_req(WRITE, COM1, green, strlen(green));
    sys_req(WRITE, COM1, "PCB successfully deleted.\n", 27);
    sys_req(WRITE, COM1, reset, strlen(reset));
}

void suspend_pcb(const char *name)
{
    // Name must be valid
    if (!name || strlen(name) == 0 || strlen(name) > 8)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Invalid process name.\n", 30);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    struct pcb *pcb_to_suspend = pcb_find(name); // Find/locate the PCB

    // Check if the PCB was found
    if (pcb_to_suspend == NULL)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: PCB not found.\n", 23);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Ensure the PCB is not a system process
    if (pcb_to_suspend->class == SYSTEM_PROCESS)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Cannot suspend system process.\n", 39);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Check if the PCB is already suspended
    if (pcb_to_suspend->suspended == SUSPENDED)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Process is already suspended.\n", 38);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Suspend the PCB
    pcb_remove(pcb_to_suspend);
    pcb_to_suspend->suspended = SUSPENDED;
    pcb_insert(pcb_to_suspend);

    sys_req(WRITE, COM1, green, strlen(green));
    sys_req(WRITE, COM1, "PCB suspended successfully.\n", 29);
    sys_req(WRITE, COM1, reset, strlen(reset));
    print_pcb(pcb_to_suspend); // Print the PCB details
}

void resume_pcb(const char *name)
{
    // Name must be valid
    if (!name || strlen(name) == 0 || strlen(name) > 8)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Invalid process name.\n", 30);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }
    struct pcb *pcb_to_resume = pcb_find(name); // Find/locate the PCB

    // Check if the PCB was found
    if (pcb_to_resume == NULL)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: The PCB you are trying to resume does not exist.\n", 57);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Ensure the PCB is not a system process
    if (pcb_to_resume->class == SYSTEM_PROCESS)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Cannot suspend a system process, therefore you cannot resume it.\n", 73);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Check if the PCB is already suspended
    if (pcb_to_resume->suspended == NOT_SUSPENDED)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: The PCB you are trying to resume is not suspended.\n", 59);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Resume the PCB
    pcb_remove(pcb_to_resume);
    pcb_to_resume->suspended = NOT_SUSPENDED;

    sys_req(WRITE, COM1, green, strlen(green));
    sys_req(WRITE, COM1, "PCB resumed successfully.\n", 27);
    sys_req(WRITE, COM1, reset, strlen(reset));

    pcb_insert(pcb_to_resume);
}

void set_pcb_priority(const char *name, int priority)
{
    // Priority must be valid
    if (priority < 0 || priority > 9)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Priority must be from 0 to 9.\n", 38);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Name must be valid
    if (name == NULL || strlen(name) == 0 || strlen(name) > 40)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Invalid process name.\n", 30);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    struct pcb *pcb_to_set_priority = pcb_find(name); // Find/locate the PCB

    // Check if the PCB was found
    if (pcb_to_set_priority == NULL)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: The PCB you're trying to set the priority for does not exist.\n", 70);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Ensure the PCB is not a system process
    if (pcb_to_set_priority->class == SYSTEM_PROCESS)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Cannot change the priority of a system process.\n", 56);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    pcb_to_set_priority->priority = priority; // Set the new priority

    // If the PCB is in the ready state, remove and reinsert it to update its position
    if (pcb_to_set_priority->state == READY)
    {
        pcb_remove(pcb_to_set_priority);
        pcb_insert(pcb_to_set_priority);
    }

    sys_req(WRITE, COM1, green, strlen(green));
    sys_req(WRITE, COM1, "PCB priority set successfully.\n", 32);
    sys_req(WRITE, COM1, reset, strlen(reset));
    print_pcb(pcb_to_set_priority); // Print the PCB details
}

void show_pcb(const char *name)
{
    struct pcb *PCB = pcb_find(name); // Find/locate the PCB

    // Name must be valid
    if (!PCB)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: PCB not found.\n", 23);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    print_pcb(PCB); // Print the PCB details
}

void show_ready(void)
{
    struct pcb *current = get_ready_queue;            // The queue of ready and unsuspended processes
    struct pcb *current2 = get_suspended_ready_queue; // The queue of ready and suspended processes

    // Check if both queues are empty
    if (!current && !current2)
    {
        sys_req(WRITE, COM1, yellow, strlen(yellow));
        sys_req(WRITE, COM1, "No PCBs in any of the ready queues.\n", 37);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Check if the ready & unsuspended queue is empty
    if (!current)
    {
        sys_req(WRITE, COM1, yellow, strlen(yellow));
        sys_req(WRITE, COM1, "No PCBs in ready & unsuspended queue.\n", 39);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }
    else
    {
        sys_req(WRITE, COM1, underline, strlen(underline));
        sys_req(WRITE, COM1, "\nReady & Unsuspended Queues:\n\n", 31);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }

    // Print the PCBs in the ready & unsuspended queue
    while (current)
    {
        print_pcb(current);      // Print the PCB details
        current = current->next; // Link to the next PCB
    }

    // Check if the ready & suspended queue is empty
    if (!current2)
    {
        sys_req(WRITE, COM1, yellow, strlen(yellow));
        sys_req(WRITE, COM1, "No PCBs in ready & suspended queue.\n", 37);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }
    else
    {
        sys_req(WRITE, COM1, underline, strlen(underline));
        sys_req(WRITE, COM1, "\nReady & Suspended Queues:\n\n", 29);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }

    // Print the PCBs in the ready & suspended queue
    while (current2)
    {
        print_pcb(current2);       // Print the PCB details
        current2 = current2->next; // Link to the next PCB
    }
}

void show_blocked(void)
{
    struct pcb *current = get_blocked_queue;            // The queue of blocked and unsuspended processes
    struct pcb *current2 = get_suspended_blocked_queue; // The queue of blocked and suspended processes

    // Check if both queues are empty
    if (!current && !current2)
    {
        sys_req(WRITE, COM1, yellow, strlen(yellow));
        sys_req(WRITE, COM1, "No PCBs in any of the blocked queues.\n", 39);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // Check if the blocked & unsuspended queue is empty
    if (!current)
    {
        sys_req(WRITE, COM1, yellow, strlen(yellow));
        sys_req(WRITE, COM1, "No PCBs in blocked & unsuspended queue.\n", 41);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }
    else
    {
        sys_req(WRITE, COM1, underline, strlen(underline));
        sys_req(WRITE, COM1, "\nBlocked & Unsuspended PCBs:\n\n", 31);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }

    // Print the PCBs in the blocked & unsuspended queue
    while (current)
    {
        print_pcb(current);      // Print the PCB details
        current = current->next; // Link to the next PCB
    }

    // Check if the blocked & suspended queue is empty
    if (!current2)
    {
        sys_req(WRITE, COM1, yellow, strlen(yellow));
        sys_req(WRITE, COM1, "No PCBs in blocked & suspended queue.\n", 39);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }
    else
    {
        sys_req(WRITE, COM1, underline, strlen(underline));
        sys_req(WRITE, COM1, "\nBlocked & Suspended PCBs:\n\n", 29);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }

    // Print the PCBs in the blocked & suspended queue
    while (current2)
    {
        print_pcb(current2);       // Print the PCB details
        current2 = current2->next; // Link to the next PCB
    }
}

void show_all(void)
{
    sys_req(WRITE, COM1, "\nDisplaying all PCBs:\n", 23);

    show_ready();   // Show ready queue
    show_blocked(); // Show blocked queue
}

// R3: Processes Helper functions
/* helper functions for each process:
 *  Each load_procX() function creates a PCB, sets it as READY, and assigns execution to procX
 */

void load_proc1_suspended(void)
{

    struct pcb *find_pcb = pcb_find("proc1");

    if (find_pcb != NULL)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Process Not Created: proc1 already exists.\n", 44);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    // call the set-up() from kernel to set up a pcb
    struct pcb *new_pcb = pcb_setup("proc1", 1, 3);
    new_pcb->suspended = SUSPENDED; // Mark the process as not suspended
    new_pcb->state = READY;         // Mark the process as ready

    struct context *new_context = (struct context *)(new_pcb->stackPtr);

    // segment registers
    new_context->cs = 0x08;
    new_context->ds = 0x10;
    new_context->es = 0x10;
    new_context->fs = 0x10;
    new_context->gs = 0x10;
    new_context->ss = 0x10;

    // set the stack and base pointers
    new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

    // EIP must be a pointer to the function of proc1 in processes.h
    new_context->eip = (unsigned int)(proc1);

    // EFLAGS must be 0x0202
    new_context->eflags = 0x0202;

    // Set general registers to 0
    new_context->eax = 0;
    new_context->ebx = 0;
    new_context->ecx = 0;
    new_context->edx = 0;
    new_context->esi = 0;
    new_context->edi = 0;

    pcb_insert(new_pcb);

    // Print a success message
    sys_req(WRITE, COM1, green, strlen(green));
    sys_req(WRITE, COM1, "Process Created Successfully: proc1.\n", 38);
    sys_req(WRITE, COM1, reset, strlen(reset));
}

void load_proc2_suspended(void)
{

    struct pcb *find_pcb = pcb_find("proc2");

    if (find_pcb != NULL)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Process Not Created: proc2 already exists.\n", 44);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    struct pcb *new_pcb = pcb_setup("proc2", 1, 3);
    new_pcb->suspended = SUSPENDED;
    new_pcb->state = READY;

    struct context *new_context = (struct context *)(new_pcb->stackPtr);

    // segment registers
    new_context->cs = 0x08;
    new_context->ds = 0x10;
    new_context->es = 0x10;
    new_context->fs = 0x10;
    new_context->gs = 0x10;
    new_context->ss = 0x10;

    new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

    new_context->eip = (unsigned int)(proc2);

    new_context->eflags = 0x0202;

    new_context->eax = 0;
    new_context->ebx = 0;
    new_context->ecx = 0;
    new_context->edx = 0;
    new_context->esi = 0;
    new_context->edi = 0;

    pcb_insert(new_pcb);

    // Print a success message
    sys_req(WRITE, COM1, green, strlen(green));
    sys_req(WRITE, COM1, "Process Created Successfully: proc2.\n", 38);
    sys_req(WRITE, COM1, reset, strlen(reset));
}

void load_proc3_suspended(void)
{
    struct pcb *find_pcb = pcb_find("proc3");

    if (find_pcb != NULL)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Process Not Created: proc3 already exists.\n", 44);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    struct pcb *new_pcb = pcb_setup("proc3", 1, 3);
    new_pcb->suspended = SUSPENDED;
    new_pcb->state = READY;

    struct context *new_context = (struct context *)(new_pcb->stackPtr);

    // segment registers
    new_context->cs = 0x08;
    new_context->ds = 0x10;
    new_context->es = 0x10;
    new_context->fs = 0x10;
    new_context->gs = 0x10;
    new_context->ss = 0x10;

    new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

    new_context->eip = (unsigned int)(proc3);

    new_context->eflags = 0x0202;

    new_context->eax = 0;
    new_context->ebx = 0;
    new_context->ecx = 0;
    new_context->edx = 0;
    new_context->esi = 0;
    new_context->edi = 0;

    pcb_insert(new_pcb);

    // Print a success message
    sys_req(WRITE, COM1, green, strlen(green));
    sys_req(WRITE, COM1, "Process Created Successfully: proc3.\n", 38);
    sys_req(WRITE, COM1, reset, strlen(reset));
}

void load_proc4_suspended(void)
{

    struct pcb *find_pcb = pcb_find("proc4");

    if (find_pcb != NULL)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Process Not Created: proc4 already exists.\n", 44);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    struct pcb *new_pcb = pcb_setup("proc4", 1, 3);
    new_pcb->suspended = SUSPENDED;
    new_pcb->state = READY;

    struct context *new_context = (struct context *)(new_pcb->stackPtr);

    // segment registers
    new_context->cs = 0x08;
    new_context->ds = 0x10;
    new_context->es = 0x10;
    new_context->fs = 0x10;
    new_context->gs = 0x10;
    new_context->ss = 0x10;

    new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

    new_context->eip = (unsigned int)(proc4);

    new_context->eflags = 0x0202;

    new_context->eax = 0;
    new_context->ebx = 0;
    new_context->ecx = 0;
    new_context->edx = 0;
    new_context->esi = 0;
    new_context->edi = 0;

    pcb_insert(new_pcb);

    // Print a success message
    sys_req(WRITE, COM1, green, strlen(green));
    sys_req(WRITE, COM1, "Process Created Successfully: proc4.\n", 38);
    sys_req(WRITE, COM1, reset, strlen(reset));
}

void load_proc5_suspended(void)
{

    struct pcb *find_pcb = pcb_find("proc5");

    if (find_pcb != NULL)
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Process Not Created: proc5 already exists.\n", 44);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    struct pcb *new_pcb = pcb_setup("proc5", 1, 3);
    new_pcb->suspended = SUSPENDED;
    new_pcb->state = READY;

    struct context *new_context = (struct context *)(new_pcb->stackPtr);

    // segment registers
    new_context->cs = 0x08;
    new_context->ds = 0x10;
    new_context->es = 0x10;
    new_context->fs = 0x10;
    new_context->gs = 0x10;
    new_context->ss = 0x10;

    new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

    new_context->eip = (unsigned int)(proc5);

    new_context->eflags = 0x0202;

    new_context->eax = 0;
    new_context->ebx = 0;
    new_context->ecx = 0;
    new_context->edx = 0;
    new_context->esi = 0;
    new_context->edi = 0;

    pcb_insert(new_pcb);

    // Print a success message
    sys_req(WRITE, COM1, green, strlen(green));
    sys_req(WRITE, COM1, "Process Created Successfully: proc5.\n", 38);
    sys_req(WRITE, COM1, reset, strlen(reset));
}

// R3: commands

void load_r3(void)
{
    // Check if processes are already loaded
    load_r3_user();
}

// loads the R3 processes in the suspended state
void load_r3_suspended(void)
{

    const char *loadMessage = "Loading suspended R3 processes into memory:\n";
    sys_req(WRITE, COM1, loadMessage, strlen(loadMessage));

    // Call each helper function to load the respective processes
    load_proc1_suspended();
    load_proc2_suspended();
    load_proc3_suspended();
    load_proc4_suspended();
    load_proc5_suspended();
}

// R4 Alarm Command
void alarm(void)
{
    setAlarm(NULL, NULL);
}

// R5 Memory Commands
void allocate_mem(size_t allocateSize)
{
    if (allocateSize == 0) // Check for invalid allocation size
    {
        sys_req(WRITE, COM1, "Error: Allocation size must be greater than 0.\n", 48);
        return;
    }

    void *allocated_block = allocate_memory(allocateSize); // Attempt to allocate memory

    if (allocated_block != NULL) // Check if allocation was successful
    {
        sys_req(WRITE, COM1, green, strlen(green));
        sys_req(WRITE, COM1, "Allocated memory at address: ", 30);
        decimalToHex((uintptr_t)allocated_block); // Convert address to hexadecimal and print
        sys_req(WRITE, COM1, "\n", 2);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }
    else
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Allocation failed. Insufficient memory available.\n", 58);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }
}

void free_mem(void *address)
{
    if (address == NULL) // Check for NULL address
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "Error: Cannot free a NULL address.\n", 36);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    int result = free_memory(address); // Attempt to free memory

    if (result == 0) // Check if freeing was successful
    {
        sys_req(WRITE, COM1, "Memory at address: ", 20);
        decimalToHex((uintptr_t)address); // Convert address to hexadecimal and print
        sys_req(WRITE, COM1, green, strlen(green));
        sys_req(WRITE, COM1, "\nFreed Successfully!\n", 22);
        sys_req(WRITE, COM1, reset, strlen(reset));
    }
    else
    {
        sys_req(WRITE, COM1, red, strlen(red));
        sys_req(WRITE, COM1, "ERROR! Failed to free memory at address: ", 42);
        decimalToHex((uintptr_t)address); // Convert address to hexadecimal and print
        sys_req(WRITE, COM1, reset, strlen(reset));
        sys_req(WRITE, COM1, "\nPlease ensure the address matches an allocated block.\n", 56);
    }
}

void show_allocated_memory(void)
{
    struct mcb *current = get_allocated_memory_list();

    if (!current)
    {
        sys_req(WRITE, COM1, yellow, strlen(yellow));
        sys_req(WRITE, COM1, "No allocated memory blocks found.\n", 34);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    sys_req(WRITE, COM1, "Allocated Memory Blocks:\n", 26);

    while (current) // Iterate through allocated blocks
    {
        sys_req(WRITE, COM1, blue, strlen(blue));
        sys_req(WRITE, COM1, "Start Address: ", 15);
        decimalToHex((uintptr_t)current->start_address); // Convert start address to hexadecimal and print

        sys_req(WRITE, COM1, ", Size: ", 8);
        char size_str[12];
        itoa(size_str, current->size);                    // Allocate a buffer for the size string
        sys_req(WRITE, COM1, size_str, strlen(size_str)); // Convert the size to a string
        sys_req(WRITE, COM1, " bytes\n", 7);
        sys_req(WRITE, COM1, reset, strlen(reset));

        current = current->next; // Move to the next block
    }
}

void show_free_memory(void)
{
    struct mcb *current = get_free_memory_list(); // Get the list of free memory blocks

    if (!current) // Check if there are no free blocks
    {
        sys_req(WRITE, COM1, yellow, strlen(yellow));
        sys_req(WRITE, COM1, "No free memory blocks available!\n", 34);
        sys_req(WRITE, COM1, reset, strlen(reset));
        return;
    }

    sys_req(WRITE, COM1, "Free Memory Blocks:\n", 21);

    while (current)
    {
        sys_req(WRITE, COM1, blue, strlen(blue));
        sys_req(WRITE, COM1, "Start Address: ", 15);
        decimalToHex((uintptr_t)current->start_address);

        sys_req(WRITE, COM1, ", Size: ", 8);
        char size_str[12]; // Allocate a buffer large enough to hold the string representation
        itoa(size_str, current->size);
        sys_req(WRITE, COM1, size_str, strlen(size_str));
        sys_req(WRITE, COM1, " bytes\n", 7);
        sys_req(WRITE, COM1, reset, strlen(reset));

        current = current->next;
    }
}
