# W Stem
