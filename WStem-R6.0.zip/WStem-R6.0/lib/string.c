#include <string.h>
#include <stdarg.h>

#include <string.h>
#include <sys_req.h>
#include <ctype.h> 

/* memcpy() and memset() are in core.c */

int strcmp(const char *s1, const char *s2)
{

	// Remarks:
	// 1) If we made it to the end of both strings (i. e. our pointer points to a
	//    '\0' character), the function will return 0
	// 2) If we didn't make it to the end of both strings, the function will
	//    return the difference of the characters at the first index of
	//    indifference.
	while ((*s1) && (*s1 == *s2)) {
		++s1;
		++s2;
	}
	return (*(unsigned char *)s1 - *(unsigned char *)s2);
}

size_t strlen(const char *s)
{
	size_t len = 0;
	while (*s++) {
		len++;
	}
	return len;
}

char *strtok(char * restrict s1, const char * restrict s2)
{
	static char *tok_tmp = NULL;
	const char *p = s2;

	//new string
	if (s1 != NULL) {
		tok_tmp = s1;
	}
	//old string cont'd
	else {
		if (tok_tmp == NULL) {
			return NULL;
		}
		s1 = tok_tmp;
	}

	//skip leading s2 characters
	while (*p && *s1) {
		if (*s1 == *p) {
			++s1;
			p = s2;
			continue;
		}
		++p;
	}

	//no more to parse
	if (!*s1) {
		return (tok_tmp = NULL);
	}
	//skip non-s2 characters
	tok_tmp = s1;
	while (*tok_tmp) {
		p = s2;
		while (*p) {
			if (*tok_tmp == *p++) {
				*tok_tmp++ = '\0';
				return s1;
			}
		}
		++tok_tmp;
	}

	//end of string
	tok_tmp = NULL;
	return s1;
}


/*@brief takes a string to format and formats unspecified amount of parameters.
Writes the formatted string to the buffer, writes the buffer to the terminal*/

//Currently any time it reaches my method, it stops (runs out of memory according to the tutor)
//Need to find a way to limit the amount of variables, buffers, etc. 
//Maybe I can get rid of the output variable as a whole. Just use format_ptr instead
void prints(char* format, ...)
{
  	va_list args;
	int i = 0;
    char* output = "";
    char* format_ptr = format;

    //Getting parameters from input
    va_start (args, format);

    //Writing and formatting string with parameters
    while(format_ptr)
    {    
        if (format_ptr[i] == '%')
        {
            //Process the argument as an integer
            if (format_ptr[i++] == 'd' || format_ptr[i++] == 'i')
            {
                int num = va_arg(args, int);
                int j = 0;
                char* str = "";
                int num_sign = num;
                
                //This is where I start converting an integer to a string
                //If the number is negative, make it positive
                if (num < 0)
                    num = -num;

                //Pull the digits out of the integer and store them in string
                while (num > 0)
                {
                    str[j++] = num % 10 + '0';
                    num /= 10;
                }

                //Add the negative sign to the string if needed
                if (num_sign < 0)
                    str[j++] = '-';
                
                //Null terminate the string
                str[j] = '\0';

                //Reverse the string to get the right order
                for (int k = 0, m = j - 1; k < m; k++, m--) 
                {
                    char temp = str[k];
                    str[k] = str[m];
                    str[m] = temp;
                }

                //End integer conversion
                //Add new integer string to output
                output[i] = *str;
            }

            //Process it as a normal % sign
            else
                output[i] = format_ptr[i];
        }

        //If not a % sign, continue as normal
        else
            output[i] = format_ptr[i];
        
        i++;
    }
    
    va_end(args);
    
	//Writing it to the terminal
    sys_req(WRITE, COM1, output, strlen(output));
}

// Copies a string from one location to another
void strcpy(char* arr, const char* str) {
	// Pointer to the returning char pointer
    char* ptr = arr;

	// While the string doesn't terminate, copy the string from one index to another
    while (*str != '\0') {
        *ptr++ = *str++;
    }
	// Terminate the copied string
    *ptr = '\0';
}

// Removes spaces from the beginning and end of a string, also checks for empty strings
void strip_spaces(char* str) {

    char* end;
    char* start = str;

    // Trim leading spaces
    while (*start == ' ') {
        start++;
    }

    // If all spaces or empty string
    if (*start == 0) {
        *str = 0;
        return;
    }

    // Trim trailing spaces
    end = start + strlen(start) - 1;
    while (end > start && *end == ' ') {
        end--;
    }

    // Write new null terminator
    *(end + 1) = '\0';

    // Move trimmed string to the beginning
    while (*start) {
        *str++ = *start++;
    }
    *str = '\0';
}
