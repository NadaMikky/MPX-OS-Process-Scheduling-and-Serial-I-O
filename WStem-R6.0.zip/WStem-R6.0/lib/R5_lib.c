#include <mpx/io.h>
#include <mpx/serial.h>
#include <mpx/vm.h>
#include <sys_req.h>
#include <string.h>
#include <memory.h>
#include <string.h>
#include <stdlib.h>
#include <R5_lib.h>

// Memory lists
static struct mcb *free_memory_list = NULL;
static struct mcb *allocated_memory_list = NULL;

// Allocates all memory available to your memory manager as a single, large free block using kmalloc()
void initialize_heap(size_t heapSize) 
{
    // Allocate memory for the initial MCB and the heap
    void *heap = kmalloc(heapSize + sizeof(struct mcb), 0, NULL);

    if (!heap) {
        return; // Failed to allocate memory
    }

    // Initialize the MCB
    struct mcb *initial_mcb = (struct mcb *)heap;
    initial_mcb->size = heapSize;
    initial_mcb->is_allocated = 0; // Mark as free memory
    initial_mcb->next = NULL;
    initial_mcb->prev = NULL; // No previous block
    initial_mcb->start_address = (void *)((char *)heap + sizeof(struct mcb));

    // Initialize the free list with this block
    set_free_memory_list(initial_mcb);

    // Initialize the allocated list as empty
    set_allocated_memory_list(NULL);
}

// Allocates memory from the heap using the first-fit strategy
void* allocate_memory(size_t allocateSize) {
    struct mcb *current = get_free_memory_list(); // Get the free list
    
    // Search for first block that fits
    while (current != NULL) {

        // Calculate total size needed including MCB
        size_t total_size = allocateSize + sizeof(struct mcb);
        
        if (current->size >= total_size) { // Found a block big enough

            if (current->size > total_size + sizeof(struct mcb)) { // Check if we need to split the block
                // Create new MCB for the remaining free space
                struct mcb *new_mcb = (struct mcb *)((char *)current->start_address + allocateSize);
                new_mcb->size = current->size - total_size;
                new_mcb->is_allocated = 0; // Mark as free memory
                new_mcb->next = current->next;
                new_mcb->prev = current;
                new_mcb->start_address = (void *)((char *)new_mcb + sizeof(struct mcb));
                
                if (current->next) {
                    current->next->prev = new_mcb;
                }
                
                current->size = allocateSize;
                current->next = new_mcb;
            }
            
            current->is_allocated = 1; // Mark block as allocated
            
            // Remove from free list using prev pointer
            if (current->prev == NULL) {
                set_free_memory_list(current->next);
                if (current->next) {
                    current->next->prev = NULL;
                }
            } else {
                current->prev->next = current->next;
                if (current->next) {
                    current->next->prev = current->prev;
                }
            }
            
            // Add to allocated list in address order
            struct mcb *allocated_list = get_allocated_memory_list();
            struct mcb *alloc_prev = NULL;
            struct mcb *alloc_current = allocated_list;
            
            // Find correct position in allocated list based on address
            while (alloc_current != NULL && alloc_current < current) {
                alloc_prev = alloc_current;
                alloc_current = alloc_current->next;
            }
            
            // Insert into allocated list
            if (alloc_prev == NULL) {
                current->next = allocated_list;
                current->prev = NULL;
                if (allocated_list) {
                    allocated_list->prev = current;
                }
                set_allocated_memory_list(current);
            } else {
                current->next = alloc_prev->next;
                current->prev = alloc_prev;
                if (alloc_prev->next) {
                    alloc_prev->next->prev = current;
                }
                alloc_prev->next = current;
            }
            
            return current->start_address;
        }
        current = current->next;
    }
    
    // No suitable block found
    return NULL;
}

// Frees allocated memory, placing the associated block on the free list
int free_memory(void *ptr) {
    // Check for NULL pointer, returns 1 for an error
    if (ptr == NULL) {
        return 1;
    }

    // Find the MCB in the allocated list
    struct mcb *current = get_allocated_memory_list();
    struct mcb *prev = NULL;
    
    // Iterate through the allocated list
    while (current != NULL) {
        if (current->start_address == ptr) { // Found the block to free
            // Remove from allocated list
            if (prev == NULL) {
                set_allocated_memory_list(current->next);
                if (current->next) {
                    current->next->prev = NULL;
                }
            } else {
                prev->next = current->next;
                if (current->next) {
                    current->next->prev = prev;
                }
            }
            
            current->is_allocated = 0; // Mark as free memory
            current->next = NULL;
            current->prev = NULL;
            
            // Get the free list for merging
            struct mcb *free_list = get_free_memory_list();
            struct mcb *free_prev = NULL;
            struct mcb *free_current = free_list;
            
            // Find where to insert in the free list (keeping addresses ordered)
            while (free_current != NULL && free_current < current) {
                free_prev = free_current;
                free_current = free_current->next;
            }
            
            // Insert into free list
            if (free_prev == NULL) {
                current->next = free_list;
                current->prev = NULL;
                if (free_list) {
                    free_list->prev = current;
                }
                set_free_memory_list(current);
            } else {
                current->next = free_prev->next;
                current->prev = free_prev;
                if (free_prev->next) {
                    free_prev->next->prev = current;
                }
                free_prev->next = current;
            }
            
            // Merge with previous block if adjacent
            if (free_prev != NULL) {
                void *prev_end = (void *)((char *)free_prev->start_address + free_prev->size); // Get the end of the previous block
                if (prev_end == (void *)current) {
                    free_prev->size += sizeof(struct mcb) + current->size;
                    free_prev->next = current->next;
                    if (current->next) {
                        current->next->prev = free_prev;
                    }
                    current = free_prev;
                }
            }
            
            // Merge with next block if adjacent
            if (current->next != NULL) {
                void *current_end = (void *)((char *)current->start_address + current->size); // Get the end of the current block
                if (current_end == (void *)current->next) {
                    current->size += sizeof(struct mcb) + current->next->size;
                    current->next = current->next->next;
                    if (current->next) {
                        current->next->prev = current;
                    }
                }
            }
            
            return 0; // Successful free
        }
        prev = current; // Update the previous block
        current = current->next; // Update the current block
    }
    
    return 1; // Unsuccessful free
}

struct mcb *get_free_memory_list(void) {
    return free_memory_list;
}

struct mcb *get_allocated_memory_list(void) {
    return allocated_memory_list;
}

void set_free_memory_list(struct mcb *list) {
    free_memory_list = list;
}

void set_allocated_memory_list(struct mcb *list) {
    allocated_memory_list = list;
}

void* sys_alloc_zeroed_mem(size_t num, size_t size) {

    void *ptr = sys_alloc_mem(num * size); // Allocate memory

    // If the ptr is not empty, zero it out
    if (ptr != NULL) {
        memset(ptr, 0, num * size);
    }

    return ptr; // Return the pointer to the allocated memory
}
