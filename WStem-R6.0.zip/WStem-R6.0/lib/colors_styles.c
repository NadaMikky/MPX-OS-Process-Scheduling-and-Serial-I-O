#include <colors_styles.h>

// ANSI escape codes for colors and styles
const char bold[] = "\x1B[1m"; // Bold for emphasis
const char underline[] = "\x1B[4m"; // Underline for emphasis
const char reset[] = "\x1B[0m"; // Back to default color
const char yellow[] = "\x1B[38;5;3m"; // Yellow means warning/highlight for emphasis
const char red[] = "\x1B[38;5;1m"; // Red for error
const char green[] = "\x1B[38;5;2m"; // Green for success
const char pink[] = "\x1B[38;5;218m"; // Pink for WSTEM logo
const char blue[] = "\x1B[38;5;38m"; // Blue for info 
