#include "numeric.h"
#include <stdarg.h>
#include "string.h"
#include "sys_req.h" 

int isDigit(char c){
    switch(c){
        case '1': 
            return 1;
        case '2': 
            return 1;
        case '3': 
            return 1;
        case '4': 
            return 1;
        case '5': 
            return 1;
        case '6': 
            return 1;
        case '7': 
            return 1;
        case '8': 
            return 1;
        case '9': 
            return 1;
        case '0': 
            return 1;
        default:
            return 0;
    }
}

int isNumeric(char* str){
    for(size_t i=0; i<strlen(str); i++){
        if(isDigit(str[i])==0){
            return 0;
        }
    }
    return 1;
}



