#include <stdlib.h>
#include <sys_req.h>
#include <ctype.h>
#include <memory.h>
#include <string.h>

int atoi(const char *s)
{
	int res = 0;
	char sign = ' ';

	while (isspace(*s)) {
		s++;
	}

	if (*s == '-' || *s == '+') {
		sign = *s;
		s++;
	}

	while ('0' <= *s && *s <= '9') {
		res = res * 10 + (*s - '0');
		s++;

	}

	if (sign == '-') {
		res = res * -1;
	}

	return res;
}

// refactor the function, calling it too much might cause memory leak & program crash 
// update it to initialize a buffer void itoa (char * buff, int i){} for project enhancement
// provide a buffer to the function with a fixed size 
void itoa(char *buff, int n) {
    int i = 0;           // Index of the string
    int sign = 0;        // 0 if positive, 1 if negative

    if (n == 0) {
        buff[i++] = '0'; // Handle 0 explicitly
        buff[i] = '\0';
        return;
    }

    if (n < 0) { // If the number is negative
        sign = 1; // Set the sign to negative
        n = -n;   // Make the number positive to work with
    }

    while (n > 0) { // While the number is greater than 0
        buff[i++] = n % 10 + '0'; // Add the digit to the string
        n = n / 10;              // Move to the next digit
    }

    if (sign) { // If the number was negative
        buff[i++] = '-'; // Add the negative sign to the string
    }

    buff[i] = '\0'; // Null-terminate the string

    // Reverse the string
    for (int l = 0, r = i - 1; l < r; l++, r--) {
        char temp = buff[l];
        buff[l] = buff[r];
        buff[r] = temp;
    }
}

// R5 Helper Functions 
int mathPower (int num, int expo){
	int result_num = 0;
	if (expo ==0){
		return 1;
	}
	else if (expo == 1){
		return num;
	}
	else{
		result_num = num * num; // set to the power of 2
		for(int i = 2; i < expo; i++){
			result_num = result_num * num; // multiply by the base number
		}
		return result_num;
	}
}

// Helper Functions to convert a decimal to a hex 
// remainder is what is going into the character array 
// everytime you divide you take the quotient and divide again until you reach a quitient of zero 
// mod % for getting a remainder 
// divide by 16 to get the next digit 
// every remainder is a hex digit to the right  
int decimalToHex(unsigned int dec){
	char hex[100]; // Array to store the hexadecimal representation
    int i = 0;     // Index for the hex array

	if (dec == 0) {
        sys_req(WRITE, COM1, "0", 1); // Print 0 if the number is 0
        return 0;
    }

    // Convert decimal to hexadecimal
    while (dec != 0) {
        int remainder = dec % 16; // Get the remainder
        if (remainder < 10) {
            hex[i++] = remainder + '0'; // Convert to ASCII for digits 0-9
        } else {
            hex[i++] = remainder - 10 + 'A'; // Convert to ASCII for letters A-F
        }
        dec = dec / 16; // Divide by 16 to get the next digit
    }
	hex[i] = '\0'; // Null-terminate the string

    // Reverse the string to get the correct hexadecimal representation
    for (int l = 0, r = i - 1; l < r; l++, r--) {
        char temp = hex[l];
        hex[l] = hex[r];
        hex[r] = temp;
    }

    // Print the hexadecimal representation
    sys_req(WRITE, COM1, hex, strlen(hex));
    return 0;
}
// Helper Function to convert a hex to a decimal 
int hexToDecimal(char *hex, unsigned int hexSize) {
    int decimal = 0; // Resulting decimal value
    int base = 1;    // Base value (16^0 initially)

    // Ensure the input string is null-terminated
    hex[hexSize] = '\0';

    // Process the string from the end to the beginning
    for (int i = hexSize - 1; i >= 0; i--) {
        if (hex[i] >= '0' && hex[i] <= '9') {
            decimal += (hex[i] - '0') * base; // Convert digit to decimal
        } else if (hex[i] >= 'A' && hex[i] <= 'F') {
            decimal += (hex[i] - 'A' + 10) * base; // Convert letter A-F to decimal
        } else if (hex[i] >= 'a' && hex[i] <= 'f') {
            decimal += (hex[i] - 'a' + 10) * base; // Convert letter a-f to decimal
        } else {
            return -1; // Invalid character in the hexadecimal string
        }
        base *= 16; // Increase the base (16^1, 16^2, etc.)
    }

    return decimal; // Return the resulting decimal value
}


