#include <mpx/io.h>
#include <mpx/serial.h>
#include <sys_req.h>
#include <string.h>

int curIndex = 0; // Cursor index
int maxCursor = 0; // Maximum index the cursor can go with meaningful data

enum uart_registers
{
	RBR = 0, // Receive Buffer
	THR = 0, // Transmitter Holding
	DLL = 0, // Divisor Latch LSB
	IER = 1, // Interrupt Enable
	DLM = 1, // Divisor Latch MSB
	IIR = 2, // Interrupt Identification
	FCR = 2, // FIFO Control
	LCR = 3, // Line Control
	MCR = 4, // Modem Control
	LSR = 5, // Line Status
	MSR = 6, // Modem Status
	SCR = 7, // Scratch
};

static int initialized[4] = {0};

static int serial_devno(device dev)
{
	switch (dev)
	{
	case COM1:
		return 0;
	case COM2:
		return 1;
	case COM3:
		return 2;
	case COM4:
		return 3;
	}
	return -1;
}

int serial_init(device dev)
{
	int dno = serial_devno(dev);
	if (dno == -1)
	{
		return -1;
	}
	outb(dev + IER, 0x00);			// disable interrupts
	outb(dev + LCR, 0x80);			// set line control register
	outb(dev + DLL, 115200 / 9600); // set bsd least sig bit
	outb(dev + DLM, 0x00);			// brd most significant bit
	outb(dev + LCR, 0x03);			// lock divisor; 8bits, no parity, one stop
	outb(dev + FCR, 0xC7);			// enable fifo, clear, 14byte threshold
	outb(dev + MCR, 0x0B);			// enable interrupts, rts/dsr set
	(void)inb(dev);					// read bit to reset port
	initialized[dno] = 1;
	return 0;
}

int serial_out(device dev, const char *buffer, size_t len)
{
	int dno = serial_devno(dev);
	if (dno == -1 || initialized[dno] == 0)
	{
		return -1;
	}
	for (size_t i = 0; i < len; i++)
	{
		outb(dev, buffer[i]);
	}
	return (int)len;
}

int serial_poll(device dev, char *buffer, size_t len)
{
	int bytesRead = 0; // Bytes read from device

	while (maxCursor <= (int)len) // While the buffer isn't full
	{
		if (inb(dev + LSR) & 0x01) // LSR indicates data is avaliable ie when the least sig. bit in the LSR (device + LSR) is set
		{

			char c = inb(dev); // Reads one byte from the device
			bytesRead++;	   // Increments the number of bytes read

			if (c == 13 || c == 10) // Got carriage return/ new line from device
			{
				outb(dev, '\n');  // Outputs a new line
				outb(dev, '\r');  //	Outputs carriage return ie. these two lines move down (new line) and right (carraige return) in the terminal
				curIndex = 0;	  // Resets the cursor
				maxCursor = 0;	  // Resets the max cursor
				return bytesRead; // Returns the number of bytes read from device
			}
			else if (c == 127) // Got handle backspace from device
			{
				if (curIndex > 0) // If cursor is not at the beginning of the buffer
				{
					shiftLeft(dev, buffer, 0);	  // Shifts the buffer to the left from current character
					serial_out(dev, "\x1B[D", 3); // Moves cursor to the left on the terminal
				}
			}
			else if ((c >= 32 && c <= 125) && maxCursor < (int)len) // Got alphanumerics, symbols, and space from device
			{
				buffer[curIndex] = c;		 // Adds the character to the buffer
				outb(dev, buffer[curIndex]); // Outputs the character to the device
				curIndex++;					 // Increments the cursor
			}
			else if (c == 27) // Got ESC char from device
			{
				if (inb(dev + LSR) & 0x01) // If there is a next byte avaliable
				{

					while (!(inb(dev + LSR) & 0x01)) // While there is no byte avaliable
					{
					}

					char nextByte = inb(dev); // Reads the next byte
					bytesRead++;			  // Increments the number of bytes read

					if (nextByte == 91) // Got [ character from device
					{

						if (inb(dev + LSR) & 0x01) // If there is a next byte avaliable
						{
							while (!(inb(dev + LSR) & 0x01)) // While there is no byte avaliable
							{
							}

							char nextChar2 = inb(dev); // Reads the next byte
							bytesRead++;			   // Increments the number of bytes read

							switch (nextChar2) // Finds the next A, B, C or D for arrows or 3 for delete
							{
							case 51:
								while (!(inb(dev + LSR) & 0x01)) // While there is no byte avaliable
								{
								}
								char nextChar3 = inb(dev); // Reads the next byte
								bytesRead++;			   //	Increments the number of bytes read

								if (nextChar3 == 126)
								{											   // Finds the ~ character
									if (curIndex < maxCursor && curIndex >= 0) // if the cursor is not at the end of the buffer or the beginning
									{
										// The point of all this is to get the cursor in a position to treat delete like a backspace and still be a proper delete for the original cursor
										serial_out(dev, "\x1B[C", 3); // Moves the cursor to the right on the terminal
										curIndex++;					  // Increments the cursor
										shiftLeft(dev, buffer, 1);	  // Shifts the buffer to the left from current character
										serial_out(dev, "\x1B[D", 3); // Moves the cursor to the left on the terminal
									}
								}
								break;
							case 67: // Finds the right arrow => sequence is ESC[C

								if (curIndex < (int)len) // If the cursor is not at the end of the buffer
								{
									serial_out(dev, "\x1B[C", 3); // Moves the cursor to the right on the terminal
									curIndex++;					  // Increments the cursor
								}
								break;

							case 68: // Finds the left arrow => sequence is ESC[D

								if (curIndex > 0) // If the cursor is not at the beginning of the buffer
								{
									serial_out(dev, "\x1B[D", 3); // Moves the cursor to the left on the terminal
									curIndex--;					  // Decrements the cursor
								}

								break; // Breaks the switch statement
							}
						}
					}
				}
			}
			else
			{
				// do nothing
			}
		}

		if (maxCursor < curIndex) // If the max cursor is less than the cursor
		{
			maxCursor = curIndex; // Set the max cursor to the cursor
		}
	}
	return -1; // Returns -1 if the buffer is full => ERROR IF REACHED
}

void shiftLeft(device dev, char *buffer, int mode)
{
	// If mode is 0, then the function is in backspace mode
	// If mode is 1, then the function is in delete mode

	if (maxCursor == curIndex && mode == 0) // If the cursor is at the end of the buffer AND its in backspace mode
	{
		curIndex--;					  // Decrements the cursor
		maxCursor--;				  // Decrements the max cursor
		buffer[curIndex] = '\0';	  // Sets the current character to null
		serial_out(dev, "\x1B[D", 3); // Moves the cursor to the left on the terminal
		outb(dev, ' ');				  // Outputs a space to the device
	}
	else if (maxCursor == curIndex && mode == 1) // If the cursor is at the end of the buffer AND its in delete mode
	{
		serial_out(dev, "\x1B[D", 3); // Moves the cursor to the left on the terminal
		outb(dev, ' ');				  // Outputs a space to the device
		curIndex--;					  // Decrements the cursor
		maxCursor--;				  // Decrements the max cursor
		buffer[curIndex] = '\0';	  // Sets the current character to null
	}
	else // If the cursor is not at the furthest place a cursor could be (ie maxCursor)
	{
		serial_out(dev, "\x1B[D", 3);			 // Moves the cursor to the left on the terminal
		buffer[curIndex - 1] = buffer[curIndex]; // Sets the character before the cursor to the one at the current
		outb(dev, buffer[curIndex - 1]);		 // Outputs the character at the cursor before the current to the device

		for (int i = curIndex; i < maxCursor - 1; i++) // Shifts the buffer to the left from the current character
		{
			buffer[i] = buffer[i + 1]; // Sets the current character to the next character
			outb(dev, buffer[i]);	   // Outputs the current character to the device
		}

		buffer[maxCursor - 1] = '\0'; // Sets the last character to null
		outb(dev, ' ');				  // Outputs a space to the device

		for (int i = curIndex; i < maxCursor; i++) // Moves the cursor to the left on the terminal to get back to the original poisiton of the cursor
		{
			serial_out(dev, "\x1B[D", 3); // Moves the cursor to the left on the terminal
		}

		curIndex--;	 // Decrements the cursor
		maxCursor--; // Decrements the max cursor
	}
}
