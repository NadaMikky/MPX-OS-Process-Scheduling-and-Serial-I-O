#include <mpx/io.h>
#include <mpx/serial.h>
#include <sys_req.h>
#include <string.h>
#include <memory.h>
#include <string.h>
#include <mpx/interrupts.h>
#include <stdlib.h>
#include <pcb.h>
#include <sys_call.h>

struct pcb *get_ready_queue;             // The head of the ready queue
struct pcb *get_blocked_queue;           // The head of the blocked queue
struct pcb *get_suspended_ready_queue;   // The head of the suspended ready queue
struct pcb *get_suspended_blocked_queue; // The head of the suspended blocked queue

struct pcb *pcb_allocate(void)
{
    struct pcb *new_pcb = (struct pcb *)sys_alloc_mem(sizeof(struct pcb)); // Initialize a new pcb

    if (new_pcb == NULL) // Check for null case
    {
        return NULL;
    }

    new_pcb->next = NULL; // Initialize next pointer
    new_pcb->prev = NULL; // Initialize prev pointer

    return new_pcb; // Return newest allocated pcb
}

int pcb_free(struct pcb *new_pcb)
{

    if (new_pcb == NULL) // Null case
    {
        return -1; // Return error
    }

    sys_free_mem(new_pcb); // Free the pcb structure

    return 0; // On success
}

struct pcb *pcb_setup(const char *name, int class, int priority)
{
    // Initialize it with data provided (name, class, and priority)
    // Then set to Ready, Not_suspended

    // Check to see if the name is not a valid name or the priority is out of bounds
    if (!name || priority < 0 || priority > 9)
    {
        return NULL; // Invalid parameters
    }

    struct pcb *new_pcb = pcb_allocate(); // Allocate a new pcb

    // Check if the new pcb was allocated correctly
    if (new_pcb == NULL)
    {
        return NULL;
    }

    memset(new_pcb, 0, sizeof(struct pcb)); // Struct set to 0, just in case

    // Set pcb elements
    strcpy(new_pcb->name, name);
    new_pcb->name[sizeof(new_pcb->name) - 1] = '\0';     // Null termination to prevent buffer overflows
    new_pcb->stackPtr = (char *)(new_pcb->stack + STACK_SIZE - sizeof(context)); // Initialize the stack pointer
    new_pcb->state = READY;                              // Set default state to READY
    new_pcb->suspended = NOT_SUSPENDED;                  // Mark the process as not suspended
    new_pcb->priority = priority;                        // Assign the given priority value to the process
    new_pcb->class = class;                              // Set the class of the process

    return new_pcb; // Return the instance
}

struct pcb *pcb_find(const char *name)
{
    // Search all process queues for the one your looking for
    if (name == NULL)
    {
        return NULL; // Return null if the name was invalid
    }

    struct pcb *queues[] = {get_ready_queue, get_blocked_queue, get_suspended_ready_queue, get_suspended_blocked_queue}; // Array of all the queues

    // Run through all of the aforementioned queues
    for (int i = 0; i < 4; i++)
    {
        struct pcb *current = queues[i]; // Instantiate a pointer to a struct pcb that is used to iterate through the process queues

        while (current != NULL) // Ensure all the queues are not null
        {
            // Compare the current pointer to name to the given name
            if (strcmp(current->name, name) == 0)
            {
                return current; // Return the pointer if it the given name of process is found
            }
            current = current->next; // If it is not the current pointer, move the point over to the next
        }
    }
    return NULL; // Return null if the process is not found
}

void pcb_insert(struct pcb *new_pcb)
{
    // Insert a PCB into the appropriate queue, based on state
    if (new_pcb == NULL)
    {
        return;
    }

    struct pcb **queue_head; // Pointer to the head of the queue

    // Determine which queue to insert into
    if (new_pcb->state == READY && new_pcb->suspended == NOT_SUSPENDED)
    {
        queue_head = &get_ready_queue; // Active processes that are ready to run
    }
    else if (new_pcb->state == BLOCKED && new_pcb->suspended == NOT_SUSPENDED)
    {
        queue_head = &get_blocked_queue; // Active processes that are waiting on a resource
    }
    else if (new_pcb->state == READY && new_pcb->suspended == SUSPENDED)
    {
        queue_head = &get_suspended_ready_queue; // Suspended processes that would otherwise be ready
    }
    else if (new_pcb->state == BLOCKED && new_pcb->suspended == SUSPENDED) // Suspended processes that are also blocked

    {
        queue_head = &get_suspended_blocked_queue;
    }
    else
    {
        return; // Invalid state and suspension status
    }

    // Insert element at head
    if (*queue_head == NULL) // Check if the queue is empty
    {
        *queue_head = new_pcb; // If it is, then put new pcb at the head
        new_pcb->next = NULL;  // Next node is null
        new_pcb->prev = NULL;  // Prev node is null
        return;
    }

    struct pcb *current = *queue_head; // Current node is head node of the queue

    // Checks if the pcb is entering a ready queue (priority)
    if (new_pcb->state == READY)
    {
        // Check the priority of the new node (big number = lower priority)
        if (new_pcb->priority < current->priority)
        {
            // If new_pcb priority is highest, put the node at the front
            new_pcb->next = current;
            new_pcb->prev = NULL;
            current->prev = new_pcb;
            *queue_head = new_pcb;
            return;
        }

        // Traverse to the end of the queue or until the priority is less (bigger number)
        while (current->next != NULL && current->next->priority <= new_pcb->priority)
        {
            current = current->next; // Move current node to the next node
        }

        // Insert the new PCB in it's correct position
        new_pcb->next = current->next;
        new_pcb->prev = current;

        // If the next node is null, then the last node is the new_pcb in the queue
        if (current->next != NULL)
        {
            current->next->prev = new_pcb;
        }
        // Insert new PCB at the end
        current->next = new_pcb;
    }
    // Adds the pcb to a blocked queue (FIFO)
    else
    {
        // Traverse to the end of the queue
        while (current->next != NULL)
        {
            current = current->next; // Move current node to the next node
        }

        // Insert new PCB at the end
        current->next = new_pcb;
        new_pcb->prev = current;
    }
}

int pcb_remove(struct pcb *new_pcb)
{
    // Remove a PCB from its current queue, but doesn't free any associated memory or data structures

    if (new_pcb == NULL) // Null case
    {
        return -1;
    }

    // Only one pcb in the queue
    if (new_pcb->prev == NULL)
    {
        // Deletes the head of the queue
        if (new_pcb->state == READY && new_pcb->suspended == NOT_SUSPENDED)
        {
            get_ready_queue = new_pcb->next;
        }
        else if (new_pcb->state == BLOCKED && new_pcb->suspended == NOT_SUSPENDED)
        {
            get_blocked_queue = new_pcb->next;
        }
        else if (new_pcb->state == READY && new_pcb->suspended == SUSPENDED)
        {
            get_suspended_ready_queue = new_pcb->next;
        }
        else if (new_pcb->state == BLOCKED && new_pcb->suspended == SUSPENDED)
        {
            get_suspended_blocked_queue = new_pcb->next;
        }
    }
    else
    {
        // Update the previous node's next pointer
        new_pcb->prev->next = new_pcb->next;
    }

    // Update the next node's previous pointer
    if (new_pcb->next != NULL)
    {
        new_pcb->next->prev = new_pcb->prev; // If the next node is not null, then update the previous pointer
    }

    new_pcb->next = NULL; // Set the next pointer to null
    new_pcb->prev = NULL; // Set the previous pointer to null

    return 0;
}

void clearAllPCBs(void){
    // Clears all PCBs from the ready and blocked queues
    get_ready_queue = NULL;
    get_blocked_queue = NULL;
    get_suspended_ready_queue = NULL;
    get_suspended_blocked_queue = NULL;
}
