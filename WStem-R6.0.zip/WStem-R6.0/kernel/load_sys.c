#include <mpx/gdt.h>
#include <mpx/interrupts.h>
#include <mpx/serial.h>
#include <mpx/vm.h>
#include <mpx/commandHandler.h>
#include <sys_req.h>
#include <string.h>
#include <memory.h>
#include <pcb.h>
#include <processes.h>

void load_comhand(void) {
 
	struct pcb *new_pcb = pcb_setup("comhand", 0, 0); // Creates the pcb for the command handler
 
	struct context *new_context = (struct context *)(new_pcb->stackPtr); // Creates the context for the command handler
 
	// Assigns the segment registers
	new_context->cs = 0x08;
	new_context->ds = 0x10;
	new_context->es = 0x10;
	new_context->fs = 0x10;
	new_context->gs = 0x10;
	new_context->ss = 0x10;
 
	// Set the stack and base pointers
	new_context->ebp = (unsigned int)(new_pcb->stack);    // Bottom of stack
 
	// EIP must be a pointer to the function comhand
	new_context->eip = (unsigned int)(comhand);
 
	new_context->eflags = 0x0202;
 
	// Set all general registers to 0
	new_context->eax = 0;
	new_context->ebx = 0;
	new_context->ecx = 0;
	new_context->edx = 0;
	new_context->esi = 0;
	new_context->edi = 0;
 
	pcb_insert(new_pcb); //  Places the process in the ready queue for execution
}

void load_sys_idle(void) {
 
	struct pcb *new_pcb = pcb_setup("sys_idle_process", 0, 9); // Creates the pcb for the idle process
 
	struct context *new_context = (struct context *)(new_pcb->stackPtr); // Creates the context for the idle process
 
	// Assigns the segment registers
	new_context->cs = 0x08;
	new_context->ds = 0x10;
	new_context->es = 0x10;
	new_context->fs = 0x10;
	new_context->gs = 0x10;
	new_context->ss = 0x10;
 
	// Set the stack and base pointers
	new_context->ebp = (unsigned int)(new_pcb->stack);    // Bottom of stack
 
	// EIP must be a pointer to the function of sys_idle_process in processes.h 
	new_context->eip = (unsigned int)(sys_idle_process);
 
	new_context->eflags = 0x0202;
 
	// Set all general registers to 0
	new_context->eax = 0;
	new_context->ebx = 0;
	new_context->ecx = 0;
	new_context->edx = 0;
	new_context->esi = 0;
	new_context->edi = 0;
 
	pcb_insert(new_pcb); //  Places the process in the ready queue for execution
 }
 
