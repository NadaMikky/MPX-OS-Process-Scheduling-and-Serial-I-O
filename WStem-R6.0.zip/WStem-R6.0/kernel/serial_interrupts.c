#include <mpx/io.h>
#include <mpx/serial.h>
#include <sys_req.h>
#include <string.h>
#include <memory.h>
#include <string.h>
#include <mpx/interrupts.h>
#include <stdlib.h>
#include <pcb.h>
#include <sys_call.h>
#include <mpx/serial_interrupts.h>
#include <mpx/io_scheduler.h>
#include <mpx/device.h>

extern void serial_isr(void*);

struct dcb *dcb_table[MAX_DEVICES] = {NULL}; // Define dcb_table

/*Helper method called in sys_call
 * Retrieves the Device Control Block (DCB) for a specified device ID.
 * searches through the global list of DCBs to find the one
 * associated with the given device ID.
 * If no matching DCB is found, it returns NULL.*/

struct dcb *get_dcb_by_device(device device_id)
{
    if(device_id==COM1){
        return dcb_table[0]; // Return the DCB for COM1
    }
    else if(device_id==COM2){
        return dcb_table[1]; // Return the DCB for COM2
    }
    else if(device_id==COM3){
        return dcb_table[2]; // Return the DCB for COM3
    }
    else if(device_id==COM4){
        return dcb_table[3]; // Return the DCB for COM4
    }
    else{
        return NULL; // Return NULL if no matching DCB is found
    }
}

int serial_open(device dev, int speed)
{
    // validate parameters -make sure param is valid-
    if (valid_device(dev) == -1 || speed <= 0)
    {
        return -1; // invalid param
    }

    int dev_int = device_id_to_int(dev); // convert the device to an int index

    if (dev_int < 0 || dcb_table[dev_int] != NULL)
    {
        return -1; // device invalid or already open
    }
    // Initialize the associated DCb, mark it as open, and set the event flag to 0, set the status to IDLE, initialize the ring buffer parameters
    struct dcb *dcb = (struct dcb *)sys_alloc_mem(sizeof(struct dcb)); // Use sys_alloc_mem

    if (!dcb)
    {
        return -1; // Memory allocation failure
    }

    memset(dcb, 0, sizeof(struct dcb)); // initialize the memory allocated for the DCB to 0
    dcb->open = 1;                      // Mark the port as open
    dcb->eventFlag = 0;                 // Set event flag to 0
    dcb->status = IDLING;               // Set status to IDLE
    dcb->ringInputIndex = 0;            // initialize ring buffer input index
    dcb->ringOutputIndex = 0;           // initialize ring buffer output index
    dcb->ringCount = 0;                 // initialize ring buffer count
    dcb->device_id = dev;              // set the device ID in the DCB
    dcb->currentIOCB = getHeadQ(dev); // set the current IOCB to the head of the queue
    dcb->inputBuffer = (char*) sys_alloc_mem(sizeof(char) * 100);            // initialize input buffer
    dcb->outputBuffer = (char*) sys_alloc_mem(sizeof(char) * 600);            // initialize input buffer

    // store the DCB in the global table
    dcb_table[dev_int] = dcb;

    // Install the appropriate ISR/ the new handler in the interrupt vector.
    idt_install(0x24, serial_isr); // calling the assembly function in serial_isr.s

    // compute the required baud rate diviser
    int baud_rate_divisor = 115200 / speed;

    // Error handling for invalid baud rate divisor
    if (baud_rate_divisor < 1 || baud_rate_divisor > 0xFFFF)
    {
        sys_free_mem(dcb); // Free allocated memory for DCB
        dcb_table[dev_int] = NULL; // Clear the DCB table entry
        return -1; // Invalid baud rate divisor
    }

    // Store the value 0x80 in the Line Control Register.
    outb(COM1 + 3, 0x80);

    // Set the baud rate divisor
    outb(COM1, (baud_rate_divisor & 0xFF)); // Least significant byte
    outb(COM1 + 1, (baud_rate_divisor >> 8) & 0xFF); // Most significant byte

    // Configure the Line Control Register for 8 data bits, no parity, 1 stop bit
    outb(COM1 + 3, 0x03);

    // Enable IRQ for this serial port
    cli();
    int mask = inb(0x21); // Read current PIC mask
    mask = mask & ~(0x10);      // Clear the bit for this device
    outb(0x21, mask);               // Write updated mask back to PIC
    sti();

    // Set the Modem Control Register
    outb(dev + 4, 0x08);

    // Enable input-ready interrupts
    outb(dev + 1, 0x01);

    return 0; // Success
}

int serial_close(device dev)
{
    // Convert the device ID to an integer index
    int dev_int = device_id_to_int(dev);

    if (dev_int < 0 || dcb_table[dev_int] == NULL)
    {
        return -201; // Serial port not open --210from document-
    }

    struct dcb *dcb = dcb_table[dev_int]; // retrieve the DCB for the given device

    // Mark port as closed
    dcb->open = 0;

    // Disable IRQ for this serial port in the PIC mask register
    unsigned char mask = inb(0x21); // Read current PIC mask
    mask |= (1 << dev_int);         // Set the bit for this device
    outb(0x21, mask);               // Write updated mask back to PIC

    // Disable all interrupts in the ACC
    outb(COM1+ 4, 0x00); // Write zero to the Modem Control Register
    outb(COM1+ 1, 0x00); // Write zero to the Interrupt Enable Register

    // Free the DCB memory and clear the global table entry
    freeDCB(dcb); // Free the DCB memory
    dcb_table[dev_int] = NULL;

    return 0; // Success
}

int serial_read(device dev, char *buf, size_t len)
{
    // Convert the device ID to an integer index
    int dev_int = device_id_to_int(dev);

    // Retrieve the DCB for the given device
    struct dcb *dcb = dcb_table[dev_int];

    // Check if the device is valid
    if (valid_device(dev)==-1)
    {
        return -304; // Device busy error code
    }

    // Check if the buffer is empty
    if (buf == NULL)
    {
        return -302; // Invalid buffer address error code
    }

    // Check if the length is valid
    if ((int)len == 0 )
    {
        return -303; // Invalid count value error code
    }

    // Check if the port is open and status is idle
    if (dcb->open == 0 || dcb->status != IDLING)
    {
        return -301; // Device not open error code
    }

    // Install the buffer pointer and counters in the DCB
    dcb->inputBufferSize = len;
    dcb->inputCount = 0;
    dcb->inputBuffer = buf; // Set the input buffer to the caller's buffer
    dcb->status = READING; // Set the status to reading

    dcb->eventFlag = 0; // Clear the caller's event flag

    cli(); // Disable interrupts

    while (dcb->inputCount < len && dcb->ringCount > 0) {
        char c = dcb->ringBuffer[dcb->ringOutputIndex];
        buf[dcb->inputCount] = c;
        dcb->inputCount++;

        dcb->ringOutputIndex = (dcb->ringOutputIndex + 1) % RING_BUFFER_SIZE;
        dcb->ringCount--;

        // Stop if we hit ENTER
        if (c == '\r' || c == '\n') {
            break;
        }
    }

    // Enable interrupts
    sti();

    if (dcb->inputCount == len || (dcb->inputCount > 0 && buf[dcb->inputCount-1] == '\n'))
    {
        dcb->eventFlag = 1;   // Set the event flag to indicate completion
        dcb->status = IDLING; // Set the status to idling
    }

    // Null-terminate the buffer if space allows
    if (dcb->inputCount < dcb->inputBufferSize)
        dcb->inputBuffer[dcb->inputCount] = '\0';
    else
        dcb->inputBuffer[dcb->inputBufferSize - 1] = '\0';

    return dcb->inputCount;
}

int serial_write(device dev, char *buf, size_t len)
{
    // Convert the device ID to an integer index
    int dev_int = device_id_to_int(dev);

    // Retrieve the DCB for the given device
    struct dcb *dcb = dcb_table[dev_int];

    // Check if device is busy
    if (dcb->eventFlag == 1)
    {
        return -304; // Device busy error code
    }

    // Check if the buffer is empty
    if (buf == NULL)
    {
        return -302; // Invalid buffer address error code
    }

    // Check if the length is valid
    if ((int)len < 0 && strlen(buf) > len)
    {
        return -303; // Invalid count value error code
    }

    // Check if the port is open and status is idle
    if (dcb->open == 0 || dcb->status != IDLING)
    {
        return -301; // Device not open error code
    }
    // Install the buffer pointer and counters in the DCB
    dcb->outputBufferSize = len;
    dcb->outputCount = 0;
    dcb->status = WRITING; // Set the status to writing
    dcb->eventFlag = 0;                         // Clear the caller's event flag
    dcb->outputBuffer = buf;              // Set the output buffer to the caller's buffer
    dcb->currentIOCB = getHeadQ(dev); // Set the current IOCB to the head of the queue
    outb(dcb->device_id, dcb->outputBuffer[dcb->outputCount++]); // Send the first char to the device

    // Enable write interrupts by setting bit 1 of the Interrupt Enable register.
    unsigned char previous = inb(COM1+ 1);
    

    // unsigned char interruptEnable = (unsigned char)(previous | 0x02);
    outb((COM1+ 1), previous | 0x02);

    return dcb->outputCount;
}

void serial_interrupt(void)
{
    // Disable interrupts
    cli();

    // Obtain the correct DCB
    struct dcb *dcb = get_dcb_by_device(COM1);

    // Check if the port is open
    if (dcb == NULL || dcb->open == 0)
    {
        outb(0x20, 0x20); // Issue EOI to the PIC
        return;         // Device not open or invalid DCB
    }

    // Read the Interrupt ID Register to determine the exact type of interrupt
    unsigned char interruptReg = (unsigned char)inb(dcb->device_id + 2);

    // Check if the interrupt was caused by the serial port (Bit 0 must be 0)
    if ((interruptReg & 1) == 1)
    {
        outb(0x20, 0x20); // Issue EOI to the PIC
        return;         // Not a serial port interrupt
    }

    // Determine the specific interrupt type based on bits 2 and 1
    int interruptType = (interruptReg >> 1) & 0x03;

    // Based on the type (input, output), pass the handling to a second function
    switch (interruptType)
    {
    case 0:
        inb(dcb->device_id + 6); // Read the modem status register
        break;
    case 1:
        serial_output_interrupt(dcb);
        break;
    case 2:
        serial_input_interrupt(dcb);
        break;
    case 3:
        inb(dcb->device_id + 5); // Read the line status register
        break;
    default:
        break; // Unknown interrupt type, do nothing
    }

    // Issue EOI to the PIC
    outb(0x20, 0x20);

    // Reenable interrupts
    sti();
}

void serial_input_interrupt(struct dcb *dcb)
{
    //  Read a character from the input register.
    char c = inb(dcb->device_id);

    if (dcb->status != READING)
    {
        // Store the character in the ring buffer
        dcb->ringBuffer[dcb->ringInputIndex] = c;
        dcb->ringInputIndex = (dcb->ringInputIndex + 1) % RING_BUFFER_SIZE;
        dcb->ringCount++;
        return; // Return to the first-level handler
    }
    else
    {
        pollChar(dcb, c); // Store the character in the requestor's input buffer
    }

    //  If the count is not completed and the character is not a new-line, return. Do not signal completion.
    if (dcb->inputCount < dcb->inputBufferSize && c != 13 && c != 10)
    {
        return; // Return to the first-level handler
    }

    //  If the count is completed:
    dcb->status = IDLING;                     // Set the status to IDLING
    dcb->eventFlag = 1;                       // Set the event flag to indicate completion
    dcb->inputBuffer[dcb->inputCount] = '\0'; // Null-terminate the input buffer
}

void serial_output_interrupt(struct dcb *dcb)
{
    // If the current status is not writing, ignore the interrupt and return
    if (dcb->status != WRITING)
    {
        return; // Return to the first-level handler
    }

    // Otherwise, if the count has not been exhausted, get the next character from the requestor’s output
    // buffer and store it in the output register. Return without signaling completion.
    if (dcb->outputCount < dcb->outputBufferSize)
    {
        char nextChar = dcb->outputBuffer[dcb->outputCount];
        outb(dcb->device_id, nextChar); // Send the character to the output register
        dcb->outputCount++;             // Increment the output count
        return;                         // Return to the first-level handler
    }
    else
    {
        dcb->status = IDLING; // Reset the status to idle
        dcb->eventFlag = 1;   // Set the event flag to indicate completion

        // Disable write interrupts by clearing bit 1 of the Interrupt Enable register
        unsigned char interruptEnable = inb(dcb->device_id + 1);
        outb(dcb->device_id + 1, interruptEnable & ~(0x02));
    }
}

int device_id_to_int(device dev)
{
    switch (dev)
    {
    case COM1:
        return 0;
    case COM2:
        return 1;
    case COM3:
        return 2;
    case COM4:
        return 3;
    default:
        return -1; // Invalid device ID
    }
}

int valid_device(device dev)
{
    switch (dev)
    {
    case COM1:
        return 0;
    case COM2:
        return 0;
    case COM3:
        return 0;
    case COM4:
        return 0;
    default:
        return -1; // Invalid device ID
    }
}

device device_int_to_dev(int i)
{
    switch (i)
    {
    case 0:
        return COM1;
    case 1:
        return COM2;
    case 2:
        return COM3;
    case 3:
        return COM4;
    default:
        return -1; // Invalid device ID
    }
}

int pollChar(struct dcb *dcb, char c)
{

    if (c == 13 || c == 10) // char is a carriage return/ new line
    {
        dcb->inputCount++;                        // Increments the input count
        outb(dcb->device_id, '\n'); // Sends the new line to the device
        return 0;                                 // Successful poll
    }
    else if (c == 127) // char is backspace
    {
        if (dcb->inputCount > 0)
        {
            shiftLeft(dcb->device_id, dcb->inputBuffer, 0);	  // Shifts the buffer to the left from current character
            serial_out(dcb->device_id, "\x1B[D", 3); // Moves cursor to the left on the terminal
            dcb->inputCount--;                        // Decrements the input count
        }
        return 0; // Successful poll
    }
    else if (c >= 32 && c <= 125) // char is alphanumerics, symbols, and space
    {
        if (dcb->inputCount < dcb->inputBufferSize - 1) { // leave space for null terminator
            dcb->inputBuffer[dcb->inputCount] = c;
            dcb->inputCount++;
            outb(dcb->device_id, c);
        }
        // else: ignore input or beep if buffer is full
        return 0;
    }
    // maybe arrows logic here
    else
    {
        return -1; // Invalid character
    }
}

void freeDCB(struct dcb *dcb)
{
    if (dcb == NULL)
    {
        return; // Nothing to free
    }
    
    sys_free_mem(dcb);               // Free the DCB itself
}
