// alarm.c

#include <string.h>
#include <mpx/commandHandler.h>
#include <mpx/io.h>
#include <sys_req.h>
#include <stdlib.h>
#include <ctype.h>
#include <getset.h>
#include <pcb.h>
#include <commands.h>
#include <processes.h>
#include <Load_R3.h>
#include <memory.h>
#include <alarm.h>

#define MAX_ALARMS 10

int alarmCount = 2;
int currentAlarmIndex;

Alarm alarms[MAX_ALARMS];

// HELPER METHODS:
// Function to compare alarm time with the current time
int CheckTime(Alarm *alarm)
{
    int curr_hh = get_hour(); // Get the current hour
    int curr_mm = get_min();  // Get the current minutes
    int curr_ss = get_sec();  // Get the current seconds

    // If alarm time is in the past or now, return 1 to trigger the alarm right away
    if ((alarm->hh < curr_hh) ||
        (alarm->hh == curr_hh && alarm->mm < curr_mm) ||
        (alarm->hh == curr_hh && alarm->mm == curr_mm && alarm->ss <= curr_ss))
    {
        return 1;
    }
    return 0;
}

/* Function to CREATE a new alarm process
 * it will read in time and message from user input then create a pcb who's function is a test alarm msg
 * get current time (from getTime from getset.c)
 * store the mssage
 */
void setAlarm(char *time, char *msg)
{
    (void)time;

    setupAlarm(12, 0, 0, msg);
}

int shouldTrigger(Alarm *alarm) {
    int hours = get_hour();
    int minutes = get_min();
    int seconds = get_sec();

    if (alarm->hh > hours)
        return 0;

    if (alarm->mm > minutes)
        return 0;

    return alarm->ss <= seconds;
}

void startAlarm(char count)
{
    while (!shouldTrigger(alarms + count)) {
        sys_req(IDLE);
    }
    sys_req(WRITE, COM1, alarms[(int) count].message, strlen(alarms[(int) count].message));
    sys_req(WRITE, COM1, "\n", 1);
    sys_req(EXIT);
}

// void test/get alarm will be in the ready que
// this is where we get the time of day and the message
// save it in a global variable/array or linked list

void setupAlarm(int hr, int min, int sec, char *msg)
{
    Alarm alarmConstruct = {
        .hh = hr,
        .mm = min,
        .ss = sec
    };
    strcpy(alarmConstruct.message, msg);
    alarms[alarmCount] = alarmConstruct;
    char alarmCountStr[3];
    itoa(alarmCountStr, alarmCount);
    char alarmName[8] = "alm";
    strcpy(alarmName + 3, alarmCountStr);
    

    currentAlarmIndex = alarmCount;

    struct pcb *new_pcb = pcb_setup(alarmName, 1, 3);
    new_pcb->suspended = NOT_SUSPENDED;
    new_pcb->state = READY;

    new_pcb->stackPtr -= 1 + sizeof(int);
    struct context *new_context = (struct context *)(new_pcb->stackPtr);


    // segment registers
    new_context->cs = 0x08;
    new_context->ds = 0x10;
    new_context->es = 0x10;
    new_context->fs = 0x10;
    new_context->gs = 0x10;
    new_context->ss = 0x10;

    new_context->ebp = (unsigned int)(new_pcb->stack); // Bottom of stack

    new_context->eip = (unsigned int)(startAlarm);

    new_context->eflags = 0x0202;

    new_context->eax = 0;
    new_context->ebx = 0;
    new_context->ecx = 0;
    new_context->edx = 0;
    new_context->esi = 0;
    new_context->edi = 0;

    char *dataPtr = (char *) new_pcb->stackPtr + sizeof(context) + sizeof(int);
    *dataPtr = (char) alarmCount;

    pcb_insert(new_pcb);
    show_all();

    alarmCount++;
}
