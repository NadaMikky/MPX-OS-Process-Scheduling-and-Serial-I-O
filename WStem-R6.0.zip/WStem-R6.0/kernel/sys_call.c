#include <mpx/io.h>
#include <processes.h>
#include <mpx/serial.h>
#include <sys_req.h>
#include <string.h>
#include <memory.h>
#include <string.h>
#include <mpx/interrupts.h>
#include <stdlib.h>
#include <pcb.h>
#include <mpx/io_scheduler.h>
#include <mpx/serial_interrupts.h>
#include <sys_call.h>
#include <mpx/vm.h>

// Global context pointer for the initial process
context *init_ctx = NULL;

// Global PCB pointers to track current and next processes
struct pcb *running_process = NULL;
struct pcb *next_process = NULL;

/* Update: R6
 * TO DO:
 * Add op code for read
 * Add op code for write
 * Will call the io_scheduler function and serial_interrupt functions
 */
context *sys_call(context *cur_context)
{
    // Check for device event flags and handle I/O completion
    check_event_flags();

    // Handle IDLE system call - used for process scheduling
    if (cur_context->eax == IDLE)
    {
        // Initialize the initial context if not already set
        if (init_ctx == NULL)
        {
            init_ctx = cur_context;
        }

        // Get the next process from the ready queue
        next_process = get_ready_queue;

        // If no processes are ready, continue with current process
        if (next_process == NULL)
        {
            return cur_context;
        }
        else
        {
            // If there is a currently running process, save its state
            if (running_process != NULL)
            {
                // Set current process to ready state and save its context
                running_process->state = READY;
                running_process->stackPtr = (char *)cur_context;
                next_process = get_ready_queue;
                pcb_insert(running_process);
            }

            // Remove and prepare the next process to run
            pcb_remove(next_process);
            running_process = next_process;
            next_process->state = RUNNING;
            context *nextStack = (context *)next_process->stackPtr;
            nextStack->eax = 0;
            return nextStack;
        }
    }
    // Handle EXIT system call - terminates the current process
    else if (cur_context->eax == EXIT)
    {
        // Get the next process from ready queue
        next_process = get_ready_queue;

        check_event_flags();

        // If no processes are ready, return to initial context
        if (next_process == NULL)
        {
            cur_context->eax = 0;
            context *temp_init = init_ctx;
            init_ctx = NULL;
            running_process = NULL;
            next_process = NULL;
            return temp_init;
        }
        else
        {
            // Remove next process from queue and free current process
            pcb_remove(next_process);
            pcb_free(running_process);
            running_process = next_process;
            cur_context->eax = 0;
            return (context *)running_process->stackPtr;
        }
    }
    // Update: R6 | Handle other system calls (read/write)
    else if (cur_context->eax == READ || cur_context->eax == WRITE)
    {
         // Initialize the initial context if not already set
        if (init_ctx == NULL)
        {
            init_ctx = cur_context;
        }

        device dev = (device)cur_context->ebx; // Device ID from ebx

        // Validate parameters
        if (!dev || !cur_context->ecx || cur_context->edx <= 0)
        {
            cur_context->eax = -1; // Invalid parameters
            return cur_context;
        }

        // Retrieve the DCB for the specified device | ebx is for addressing memory
        struct dcb *device_dcb = get_dcb_by_device(dev); // Assume this function retrieves the DCB by device ID

        if (!device_dcb || !device_dcb->open)
        {
            cur_context->eax = -1; // Device not available
            return cur_context;
        }

        io_scheduler(cur_context->eax, device_dcb->device_id, (char *)cur_context->ecx, cur_context->edx, running_process);

       

        // Get the next process from the ready queue
        next_process = get_ready_queue;

        // If no processes are ready, continue with current process
        if (next_process == NULL)
        {
            return cur_context;
        }
        else
        {
            // If there is a currently running process, save its state
            if (running_process != NULL)
            {
                // Set current process to blocked state and save its context
                pcb_remove(running_process);
                running_process->state = BLOCKED;
                running_process->stackPtr = (char *)cur_context;
                next_process = get_ready_queue;
                pcb_insert(running_process);
            }

            // Remove and prepare the next process to run
            pcb_remove(next_process);
            running_process = next_process;
            next_process->state = RUNNING;
            context *nextStack = (context *)next_process->stackPtr;
            nextStack->eax = 0;
            return nextStack;
        }
    }
    else
    {
        cur_context->eax = -1;
        return cur_context;
    }
}
