#include <string.h>
#include <mpx/io.h>
#include <mpx/interrupts.h>
#include <sys_req.h>
#include <stdlib.h>
#include <getset.h>
#include <memory.h>
#include <usergetset.h>

// add a buffer as a parameter to the function to avoid memory leak 
char *concat(const char *str1, const char *str2, char *buffer)
{
    // Dynamically allocate memory for the concatenation
    char *output = buffer; // Use the provided buffer instead of allocating new memory  

    // Increment the characters in str1 in the for loop
    int output_index = 0;
    for (int i = 0; i < (int)strlen(str1); i++)
    {
        output[output_index++] = str1[i];
    }

    // Increment the characters in str2 in the for loop
    for (int i = 0; i < (int)strlen(str2); i++)
    {
        output[output_index++] = str2[i];
    }
    output[output_index++] = '\0'; // Newline after all of the chars

    // Return the output
    return output;
}

int get_hour(void)
{

    int bcd_hr = 0;
    int dec_hr = 0;

    outb(0x70, 0x04);
    bcd_hr = inb(0x71);

    dec_hr = (((bcd_hr >> 4) * 10) + (bcd_hr & 0x0F));

    return dec_hr;
}

int get_min(void)
{

    int bcd_min = 0;
    int dec_min = 0;

    outb(0x70, 0x02);
    bcd_min = inb(0x71);

    dec_min = (((bcd_min >> 4) * 10) + (bcd_min & 0x0F));

    return dec_min;
}

int get_sec(void)
{

    int bcd_sec = 0;

    // Initialize DECIMAL seconds
    int dec_sec = 0;

    // Read in the sec, min, hr
    outb(0x70, 0x00);
    bcd_sec = inb(0x71);

    // Convert binary to decimal
    dec_sec = (((bcd_sec >> 4) * 10) + (bcd_sec & 0x0F));

    return dec_sec;
}

char *get_time(void)
{
    // Disable interrupts
    cli();

    // Initialize hour, min, and sec to the int from the get-methods
    int hour = get_hour();
    int min = get_min();
    int sec = get_sec();

    // Buffers for string conversion
    char hour_str[3], min_str[3], sec_str[3];
    itoa(hour_str, hour);
    itoa(min_str, min);
    itoa(sec_str, sec);

    // Ensure all date strings have 2 characters by adding a leading '0' if necessary
    if (strlen(hour_str) == 1) {
        char temp[3];
        concat("0", hour_str, temp);
        strcpy(hour_str, temp);
    }
    if (strlen(min_str) == 1) {
        char temp[3];
        concat("0", min_str, temp);
        strcpy(min_str, temp);
    }
    if (strlen(sec_str) == 1) {
        char temp[3];
        concat("0", sec_str, temp);
        strcpy(sec_str, temp);
    }

    // Buffers for concatenation
    static char time[9]; // Final time string buffer
    char temp[9];        // Temporary buffer for intermediate concatenation

    // Format the time
    concat(hour_str, ":", temp);
    concat(temp, min_str, time);
    concat(time, ":", temp);
    concat(temp, sec_str, time);

    // Reenable interrupts
    sti();
    return time;
}

void set_time(int hour, int min, int sec)
{
    // Disables interrupts
    cli();

    // Convert to BCD format
    int bcd_hour = ((hour / 10) << 4) | (hour % 10);
    int bcd_min = ((min / 10) << 4) | (min % 10);
    int bcd_sec = ((sec / 10) << 4) | (sec % 10);

    outb(0x70, 0x04);     // Write an index to the RTC index register (0x70) with outb()
    outb(0x71, bcd_hour); // Write a new value to that index of the RTC data register (0x71) using outb()

    outb(0x70, 0x02);
    outb(0x71, bcd_min);

    outb(0x70, 0x00);
    outb(0x71, bcd_sec);

    sys_req(WRITE, COM1, "\x1B[38;5;2m", 10); // Green means success
    sys_req(WRITE, COM1, "Successful Set -> New time: ", 29);
    sys_req(WRITE, COM1, "\x1B[0m", 4); // Back to default color

    get_time_cmd();

    // Reenable interrupts
    sti();
}

int days_in_month(int month, int year , int century)
{
    // Adds the century to the year b/c leap year logic needs both
    year += century *100;

    // Switch case to run through all 12 months
    switch (month)
    {
    case 1: // Jan
        return 31; // 31 days in Jan
    case 2: // Feb
        if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0)) // Leap year logic
            return 29; // 29 in Feb is leap year
        return 28; // 28 in Feb is not a leap year
    case 3: // Mar
        return 31; // 31 days in Mar
    case 4: // Apr
        return 30; // 30 days in Apr
    case 5: // May
        return 30; // 30 days in May
    case 6: // June
        return 30; // 30 days in June
    case 7: // Jul
        return 31; // 31 days in Jul
    case 8: // Aug
        return 31; // 31 days in Aug
    case 9: // Sept
        return 30; // 30 days in Sept
    case 10: // Oct
        return 31; // 31 days in Oct
    case 11: // Nov
        return 30; // 30 days in Nov
    case 12: // Dec
        return 31; // 31 days in Dec
    }
    return -1; // Return -1 if error
}

int get_century(void)
{
    int bcd_century = 0; // Binary Coded Decimal century
    int dec_century = 0; // Decimal Century

    outb(0x70, 0x32); // Selects the register to read from using port 0x70 (0x32 for century)
    bcd_century = inb(0x71); // Reads the actual value from that register using port 0x71

    dec_century = (((bcd_century >> 4) * 10) + (bcd_century & 0x0F)); // Converts binary decimal coded century to decimal

    return dec_century; // Returns the century in decimal
}

int get_year(void)
{
    int bcd_year = 0; //  Binary Coded Decimal year
    int dec_year = 0; // Decimal Year

    outb(0x70, 0x09); // Selects the register to read from using port 0x70 (0x09 for year)
    bcd_year = inb(0x71); // Reads the actual value from that register using port 0x71

    dec_year = (((bcd_year >> 4) * 10) + (bcd_year & 0x0F)); // Converts binary decimal coded year to decimal

    return dec_year; // Returns the year in decimal
}

int get_month(void)
{
    int bcd_month = 0; // Binary Coded Decimal month
    int dec_month = 0; // Decimal month

    outb(0x70, 0x08); // Selects the register to read from using port 0x70 (0x08 for month)
    bcd_month = inb(0x71); // Reads the actual value from that register using port 0x71

    dec_month = (((bcd_month >> 4) * 10) + (bcd_month & 0x0F)); // Converts binary decimal coded month to decimal

    return dec_month; // Returns the month in decimal
}

int get_day(void)
{
    int bcd_day = 0; // Binary Coded Decimal day
    int dec_day = 0; // Decimal day

    outb(0x70, 0x07); // Selects the register to read from using port 0x70 (0x07 for day)
    bcd_day = inb(0x71); // Reads the actual value from that register using port 0x71

    dec_day = (((bcd_day >> 4) * 10) + (bcd_day & 0x0F)); // Converts binary decimal coded day to decimal

    return dec_day; // Returns the day in decimal

    // Reenable interrupts
    sti();
}

char *get_date(void)
{
    // Disable interrupts
    cli();

    // Getting the date variables
    int century = get_century();
    int year = get_year();
    int month = get_month();
    int day = get_day();

    // Buffers for string conversion
    char century_str[3], year_str[3], month_str[3], day_str[3];
    itoa(century_str, century);
    itoa(year_str, year);
    itoa(month_str, month);
    itoa(day_str, day);

    // Ensure all date strings have 2 characters by adding a leading '0' if necessary
    if (strlen(century_str) == 1) {
        char temp[3];
        concat("0", century_str, temp);
        strcpy(century_str, temp);
    }
    if (strlen(year_str) == 1) {
        char temp[3];
        concat("0", year_str, temp);
        strcpy(year_str, temp);
    }
    if (strlen(month_str) == 1) {
        char temp[3];
        concat("0", month_str, temp);
        strcpy(month_str, temp);
    }
    if (strlen(day_str) == 1) {
        char temp[3];
        concat("0", day_str, temp);
        strcpy(day_str, temp);
    }

    // Format the date in MM/DD/CCYY format
    static char date[11]; // Final date string buffer
    char temp[11];        // Temporary buffer for intermediate concatenation
    concat(month_str, "/", date);
    concat(date, day_str, temp);
    concat(temp, "/", date);
    concat(date, century_str, temp);
    concat(temp, year_str, date);

    // Reenable interrupts
    sti();

    return date; // Returns the formatted date
}

void set_date(int century, int year, int month, int day)
{
    // Disable interrupts
    cli();

    // Convert to BCD format
    int bcd_century = ((century / 10) << 4) | (century % 10);
    int bcd_year = ((year / 10) << 4) | (year % 10);
    int bcd_month = ((month / 10) << 4) | (month % 10);
    int bcd_day = ((day / 10) << 4) | (day % 10);

    outb(0x70, 0x32);     // Selects the register to read from using port 0x70 (0x32 for century)
    outb(0x71, bcd_century); // Reads the actual value from that register using port 0x71

    outb(0x70, 0x09);     // Selects the register to read from using port 0x70 (0x09 for year)
    outb(0x71, bcd_year); // Reads the actual value from that register using port 0x71

    outb(0x70, 0x08); // Selects the register to read from using port 0x70 (0x08 for month)
    outb(0x71, bcd_month); // Reads the actual value from that register using port 0x71
 
    outb(0x70, 0x07); // Selects the register to read from using port 0x70 (0x07 for day)
    outb(0x71, bcd_day); // Reads the actual value from that register using port 0x71

    sys_req(WRITE, COM1, "\x1B[38;5;2m", 10); // Green means success
    sys_req(WRITE, COM1, "Successful Set -> New date: ", 29);
    sys_req(WRITE, COM1, "\x1B[0m", 4); // Back to default color

    get_date_cmd(); // Calls the user side get_date command

    // Enable interrupts (sti())
    sti();
}
