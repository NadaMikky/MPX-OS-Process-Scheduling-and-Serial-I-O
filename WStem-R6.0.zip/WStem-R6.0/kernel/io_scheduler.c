#include <mpx/io.h>
#include <mpx/serial.h>
#include <sys_req.h>
#include <string.h>
#include <memory.h>
#include <string.h>
#include <mpx/interrupts.h>
#include <stdlib.h>
#include <pcb.h>
#include <sys_call.h>
#include <mpx/serial_interrupts.h>
#include <mpx/io_scheduler.h>
#include <commands.h>

struct iocb **headQCOM1 = NULL;
struct iocb **headQCOM2 = NULL;
struct iocb **headQCOM3 = NULL;
struct iocb **headQCOM4 = NULL;
int allocated = 0; // Flag to check if the heads are allocated

/*
 * Helper Method: check_event_flag()
 * Iterates through devices
 * global var int var, when opening dev,one global for each device (up to 4)
 * pass the pointer to the adress tot he device driver
 * flag is saved to the dcb , device driver sets when it sets an operations and clears it when done
 */

void check_event_flags(void)
{
    if(allocated==0){
        allocateIOCBHeads(); // Allocate the IOCB heads if not already done
        allocated = 1; // Set the flag to indicate allocation is done
    }

    // Iterate through all devices
    for (int i = 0; i < 3; i++)
    {   
        struct dcb *device_dcb = dcb_table[i]; // Get the DCB for the device

        if (device_dcb != NULL)
        {
            // Check if the event flag is set
            if (device_dcb->eventFlag ==1)
            {
                struct iocb **head = getHeadQ(device_dcb->device_id);
                struct iocb *completed_iocb = dequeue_iocb(head);

                if (completed_iocb)
                {
                    // Unblock the PCB associated with the IOCB
                    completed_iocb->pcb->state = READY;
                    pcb_insert(completed_iocb->pcb); // Reinsert the PCB into the ready queue

                    // Mark as uncomplete
                    device_dcb->eventFlag = 0;

                }
                // Free iocb mem
                iocb_free(completed_iocb);
            }
        }
    }
}

void enqueue_iocb(struct iocb *iocb, struct iocb **head)
{
    if (iocb == NULL || head == NULL)
    {
        return;
    }

    iocb->next = NULL; // The new IOCB should point to NULL

    if (*head == NULL)
    {
        // If the queue is empty, the incoming IOCB becomes the head
        *head = iocb;
    }
    else
    {
        // Otherwise, find the end of the queue and attach the new IOCB
        struct iocb *current = *head;
        while (current->next != NULL)
        {
            current = current->next;
        }
        current->next = iocb;
    }
}

struct iocb* dequeue_iocb(struct iocb **head)
{
    if (head == NULL)
    {
        return NULL; // Queue is empty
    }

    struct iocb *removed = *head;   // Remove the current head
    *head = (*head)->next;          // Move the head pointer to the next element
    removed->next = NULL;           // Clean the removed IOCB's next pointer

    return removed;
}


void io_scheduler(op_code operation, device dev, char *buffer, size_t size, struct pcb* pcb)
{
    // Validate system call parameters
    if (buffer == NULL || size == 0 || (operation != WRITE && operation != READ)) {
        return; // Invalid parameters
    }

    // Retrieve the DCB for the requested device
    struct dcb *device_dcb = get_dcb_by_device(dev);
    if (device_dcb == NULL) {
        return; // Device has no associated DCB
    }

    // Check the status of the requested device
    if (device_dcb->status == IDLING) {
        // Device is available, begin processing request immediately
        if (operation == READ) {
            serial_read(dev, buffer, size);
        } else if (operation == WRITE) {
            serial_write(dev, buffer, size);
        }
    }
    if(device_dcb->status == WRITING || device_dcb->status == READING) {
        // Device is busy, add an IOCB to the appropriate queue
        struct iocb *new_iocb = (struct iocb *)sys_alloc_mem(sizeof(struct iocb));
        if (new_iocb == NULL) {
            return; // Memory allocation failure
        }

        // Initialize the IOCB
        new_iocb->operation_type = operation;
        new_iocb->dcb = get_dcb_by_device(dev);
        new_iocb->buffer = buffer;
        new_iocb->buffer_size = size;
        new_iocb->pcb = pcb;
        new_iocb->next = NULL;

        // Enqueue the IOCB to the appropriate queue
        struct iocb **head = getHeadQ(dev);
        enqueue_iocb(new_iocb, head);        

        // Block the current process
        new_iocb->pcb->state = BLOCKED;
    }
}

void iocb_free(struct iocb *iocb)
{
    if (iocb == NULL)
    {
        return;
    }
    sys_free_mem(iocb); 
}

struct iocb **getHeadQ(device dev)
{
    switch (dev)
    {
    case COM1:
        return headQCOM1;
    case COM2:
        return headQCOM2;
    case COM3:
        return headQCOM3;
    case COM4:
        return headQCOM4;
    default:
        return NULL;
    }
}

// Makes the four 4 byte allocated memory blocks
void allocateIOCBHeads(void)
{
    headQCOM1 = (struct iocb **)sys_alloc_mem(sizeof(struct iocb *));
    headQCOM2 = (struct iocb **)sys_alloc_mem(sizeof(struct iocb *));
    headQCOM3 = (struct iocb **)sys_alloc_mem(sizeof(struct iocb *));
    headQCOM4 = (struct iocb **)sys_alloc_mem(sizeof(struct iocb *));
}

void freeIOCBHeads(void)
{
    sys_free_mem(headQCOM1);
    sys_free_mem(headQCOM2);
    sys_free_mem(headQCOM3);
    sys_free_mem(headQCOM4);
}
